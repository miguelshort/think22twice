package app.thinktwice.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.thinktwice.core.*
import app.thinktwice.data.Store
import app.thinktwice.system.Perms
import app.thinktwice.ui.Dest
import app.thinktwice.ui.LocalNav
import app.thinktwice.ui.LocalResumeTick
import app.thinktwice.ui.components.*
import app.thinktwice.ui.theme.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

private val es = Locale("es", "ES")
private val dShort = DateTimeFormatter.ofPattern("d MMM", es)

@Composable
fun StatsScreen(state: AppState) {
    val ctx = LocalContext.current
    val nav = LocalNav.current
    val tick = LocalResumeTick.current
    var mode by rememberSaveable { mutableIntStateOf(1) } // 0 día, 1 semana, 2 mes
    var selected by rememberSaveable(mode) { mutableStateOf<Int?>(null) }
    var classifying by remember { mutableStateOf<String?>(null) }
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now(zone)
    val span = when (mode) { 0 -> 1; 1 -> 7; else -> 30 }
    // Periodo mostrado (incluye hoy) + dos periodos completos para comparar.
    val fetchFrom = today.minusDays((span * 2).toLong())
    val range by rememberRangeUsage(fetchFrom, span * 2 + 1)
    val hasPerm = remember(tick) { Perms.hasUsageAccess(ctx) }

    DetailScaffold("Estadísticas", actions = {
        CircleIconButton(Icons.Rounded.IosShare, "Compartir resumen", {
            val text = buildSummary(state, (range as? RangeResult.Done)?.days.orEmpty(), span, today)
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Compartir resumen"))
        })
    }) {
        item {
            Segmented(listOf("Día", "Semana", "Mes"), mode, { mode = it }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(20.dp))
        }
        if (!hasPerm) item {
            Banner(BannerKind.Error, "Sin acceso a datos de uso", "Concede el acceso para ver tiempos reales. thinktwice no muestra cifras inventadas.",
                "Conceder acceso") { Perms.open(ctx, Perms.usageAccessIntent(ctx)) }
            Spacer(Modifier.height(16.dp))
        }
        val days = (range as? RangeResult.Done)?.days
        if (days == null) { item { Text("Cargando datos reales…", style = Type.secondary) }; return@DetailScaffold }

        val current = days.takeLast(span)                            // periodo mostrado (incluye hoy)
        val lastComplete = days.dropLast(1).takeLast(span)          // últimos días completos
        val prevComplete = days.dropLast(1 + span).takeLast(span)   // periodo completo anterior equivalente
        val curUsage = Productivity.sum(current.mapNotNull { it.second })
        val withData = current.count { it.second != null }

        item {
            Text(when (mode) { 0 -> "Hoy"; 1 -> "Últimos 7 días"; else -> "Últimos 30 días" }, style = Type.secondary)
            HeroDuration(if (withData == 0) null else curUsage.values.sum())
            if (mode != 0) Text("$withData de $span días con datos · media ${if (withData == 0) "—" else Fmt.duration(curUsage.values.sum() / withData)} por día con datos", style = Type.label)
            Spacer(Modifier.height(8.dp))
            ComparisonLine(lastComplete, prevComplete, span)
        }
        if (mode != 0) item {
            Spacer(Modifier.height(20.dp))
            TTCard {
                val sel = selected
                val label = if (sel != null && sel < current.size) {
                    val (d, u) = current[sel]
                    "${d.format(DateTimeFormatter.ofPattern("EEE d", es))} · ${u?.let { Fmt.duration(it.values.sum()) } ?: "sin datos"}"
                } else "Toca una barra para ver el dato"
                Text(label, style = Type.bodyMedium, modifier = Modifier.padding(bottom = 12.dp))
                BarChart(
                    values = current.map { it.second?.values?.sum() },
                    labels = current.map { (d, _) -> if (mode == 1) d.format(DateTimeFormatter.ofPattern("EEEEE", es)).uppercase() else d.dayOfMonth.toString() },
                    selected = sel, onSelect = { selected = if (selected == it) null else it },
                )
            }
        }
        item {
            SectionHeader("Productividad")
            val pct = Productivity.percent(curUsage, state.classes)
            TTCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Ring(pct)
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (pct == null) "Sin datos suficientes" else "$pct % de uso clasificado como útil", style = Type.cardTitle)
                        Spacer(Modifier.height(4.dp))
                        Text(if (mode == 0) "Hoy" else "Calculado con los tiempos acumulados del periodo, no con la media de porcentajes diarios.", style = Type.secondary)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text("Fórmula: tiempo en apps útiles ÷ (útiles + distractoras) × 100. Se excluyen las neutras y las no clasificadas porque no indican intención. Es un indicador de cómo usas el móvil según tu clasificación, no una medida de tu productividad personal.", style = Type.label)
                Spacer(Modifier.height(10.dp))
                SmallPill("Clasificar apps", { nav.push(Dest.Classify) }, Icons.Rounded.Tune)
            }
        }
        item { SectionHeader("Por aplicación") }
        val sorted = curUsage.entries.sortedByDescending { it.value }
        if (sorted.isEmpty()) item { EmptyState(Icons.Rounded.BarChart, "Sin datos suficientes", "Cuando Android registre uso en este periodo aparecerá aquí.") }
        else item {
            ListGroup {
                sorted.take(25).forEachIndexed { i, (pkg, ms) ->
                    if (i > 0) RowDivider()
                    AppUsageRow(pkg, ms, classLabel(state.classes[pkg])) { classifying = pkg }
                }
            }
        }
        item {
            SectionHeader("Pausas y decisiones")
            val start = current.first().first.atStartOfDay(zone).toInstant().toEpochMilli()
            val ev = state.events.filter { it.t >= start }
            ListGroup {
                ListRow("Pausas mostradas", null, leading = { RowIcon(Icons.Rounded.HourglassTop) }, value = "${ev.count { it.type == EventType.PAUSE_SHOWN }}")
                RowDivider()
                ListRow("Decidiste no continuar", "Saliste sin entrar a la app", leading = { RowIcon(Icons.Rounded.DoNotTouch, tint = TT.Positive) }, value = "${ev.count { it.type == EventType.EXITED }}")
                RowDivider()
                ListRow("Continuaste", null, leading = { RowIcon(Icons.Rounded.Login) }, value = "${ev.count { it.type == EventType.CONTINUED }}")
                RowDivider()
                ListRow("Intentos durante un bloqueo", null, leading = { RowIcon(Icons.Rounded.Lock) }, value = "${ev.count { it.type == EventType.BLOCK_SHOWN }}")
            }
            Text("No se convierte el tiempo bloqueado en «tiempo recuperado»: solo se cuentan decisiones registradas.", style = Type.label, modifier = Modifier.padding(top = 8.dp))
        }
        item {
            SectionHeader("Sesiones", "Historial") { nav.push(Dest.Sessions) }
            val start = current.first().first.atStartOfDay(zone).toInstant().toEpochMilli()
            val now = System.currentTimeMillis()
            val ss = state.sessions.filter { it.startMs >= start }
            ListGroup {
                ListRow("Completadas", null, leading = { RowIcon(Icons.Rounded.CheckCircle, tint = TT.Positive) }, value = "${ss.count { it.completed(now) }}")
                RowDivider()
                ListRow("Terminadas antes", "Salida de emergencia", leading = { RowIcon(Icons.Rounded.Close, tint = TT.Danger) }, value = "${ss.count { it.endedEarlyAtMs != null }}")
            }
        }
        if (mode == 2) item {
            SectionHeader("Resumen mensual")
            TTCard {
                val best = current.filter { it.second != null }.minByOrNull { it.second!!.values.sum() }
                Text("Días con datos: $withData de 30", style = Type.body)
                Text("Total registrado: ${if (withData == 0) "—" else Fmt.duration(curUsage.values.sum())}", style = Type.body)
                best?.let { Text("Día con menos uso: ${it.first.format(dShort)} (${Fmt.duration(it.second!!.values.sum())})", style = Type.body) }
                Spacer(Modifier.height(8.dp))
                Text("Android conserva un historial detallado limitado; los días anteriores sin registro aparecen como «sin datos», nunca como cero.", style = Type.label)
            }
        }
    }

    classifying?.let { pkg -> ClassifySheet(pkg, state.classes[pkg]) { classifying = null } }
}

@Composable
private fun ComparisonLine(last: List<Pair<LocalDate, DayUsage?>>, prev: List<Pair<LocalDate, DayUsage?>>, span: Int) {
    if (last.size < span || prev.size < span || last.any { it.second == null } || prev.any { it.second == null }) {
        Text("Comparación no disponible: faltan datos de algún día del periodo de referencia.", style = Type.label)
        return
    }
    val a = last.sumOf { it.second!!.values.sum() }
    val b = prev.sumOf { it.second!!.values.sum() }
    val ref = if (span == 1) "${last.first().first.format(dShort)} vs. ${prev.first().first.format(dShort)}"
    else "${last.first().first.format(dShort)}–${last.last().first.format(dShort)} vs. ${prev.first().first.format(dShort)}–${prev.last().first.format(dShort)}"
    val diff = a - b
    val txt = when {
        b == 0L -> "Sin uso en el periodo de referencia"
        abs(diff) < 60_000 -> "Igual que el periodo anterior"
        diff < 0 -> "${Fmt.duration(-diff)} menos que el periodo anterior"
        else -> "${Fmt.duration(diff)} más que el periodo anterior"
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.material3.Icon(if (diff <= 0) Icons.Rounded.SouthEast else Icons.Rounded.NorthEast, null,
            tint = if (diff <= 0) TT.Positive else TT.TextSecondary, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(txt, style = Type.secondary.copy(color = TT.Text))
    }
    Text("Días completos: $ref", style = Type.label)
}

@Composable
fun ClassifySheet(pkg: String, current: AppClass?, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    TTSheet(onDismiss, appLabel(pkg)) {
        Text("¿Cómo encaja esta app con tu intención? No hay una clasificación universal.", style = Type.secondary)
        Spacer(Modifier.height(16.dp))
        ListGroup {
            listOf(AppClass.USEFUL to "Útil", AppClass.DISTRACTING to "Distractora", AppClass.NEUTRAL to "Neutra", null to "Sin clasificar").forEachIndexed { i, (c, l) ->
                if (i > 0) RowDivider()
                ListRow(l, null, leading = { RowIcon(if (c == current) Icons.Rounded.RadioButtonChecked else Icons.Rounded.RadioButtonUnchecked, tint = if (c == current) TT.Accent else TT.TextSecondary) },
                    onClick = {
                        Store.update { s -> s.copy(classes = if (c == null) s.classes - pkg else s.classes + (pkg to c)) }
                        nav.show("Clasificada como ${l.lowercase()}"); onDismiss()
                    })
            }
        }
    }
}

@Composable
fun ClassifyScreen(state: AppState) {
    val apps by rememberInstalledApps()
    var classifying by remember { mutableStateOf<String?>(null) }
    DetailScaffold("Clasificar apps") {
        item {
            Text("Útil, distractora o neutra según tu intención. Se usa solo para el indicador de productividad y los retos de uso.", style = Type.secondary)
            Spacer(Modifier.height(16.dp))
        }
        val list = apps
        if (list == null) item { Text("Cargando…", style = Type.secondary) }
        else item {
            ListGroup {
                list.forEachIndexed { i, a ->
                    if (i > 0) RowDivider()
                    ListRow(a.label, classLabel(state.classes[a.pkg]), leading = { AppIcon(a.pkg) }, chevron = true, onClick = { classifying = a.pkg })
                }
            }
        }
    }
    classifying?.let { ClassifySheet(it, state.classes[it]) { classifying = null } }
}

@Composable
fun SessionsScreen(state: AppState) {
    val now = System.currentTimeMillis()
    val zone = ZoneId.systemDefault()
    val fmt = DateTimeFormatter.ofPattern("EEE d MMM, HH:mm", es)
    DetailScaffold("Historial de sesiones") {
        val list = state.sessions.sortedByDescending { it.startMs }
        if (list.isEmpty()) item { EmptyState(Icons.Rounded.History, "Sin sesiones", "Las sesiones de bloqueo que inicies aparecerán aquí.") }
        else item {
            ListGroup {
                list.forEachIndexed { i, s ->
                    if (i > 0) RowDivider()
                    val status = when { s.isActive(now) -> "Activa"; s.endedEarlyAtMs != null -> "Terminada antes"; else -> "Completada" }
                    ListRow(s.name, "${Instant.ofEpochMilli(s.startMs).atZone(zone).format(fmt)} · ${appsSummary(s.packages.size)}\n$status",
                        leading = { RowIcon(if (s.endedEarlyAtMs != null) Icons.Rounded.Close else Icons.Rounded.Lock, tint = if (s.endedEarlyAtMs != null) TT.Danger else TT.Text) },
                        value = Fmt.duration(s.effectiveEnd().coerceAtMost(maxOf(now, s.startMs)) - s.startMs))
                }
            }
        }
    }
}

private fun buildSummary(state: AppState, days: List<Pair<LocalDate, DayUsage?>>, span: Int, today: LocalDate): String {
    val cur = days.takeLast(span)
    val u = Productivity.sum(cur.mapNotNull { it.second })
    val pct = Productivity.percent(u, state.classes)
    val period = if (span == 1) "Hoy" else "Del ${cur.first().first.format(dShort)} al ${today.format(dShort)}"
    return buildString {
        appendLine("thinktwice · resumen")
        appendLine(period)
        appendLine("Tiempo de uso registrado: ${if (cur.all { it.second == null }) "sin datos" else Fmt.duration(u.values.sum())}")
        appendLine("Uso clasificado como útil: ${pct?.let { "$it %" } ?: "sin datos suficientes"}")
        val start = cur.first().first.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val ev = state.events.filter { it.t >= start }
        appendLine("Pausas: ${ev.count { it.type == EventType.PAUSE_SHOWN }} · no continuaste: ${ev.count { it.type == EventType.EXITED }}")
    }
}
