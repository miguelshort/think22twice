package app.thinktwice.system

import android.accessibilityservice.AccessibilityService
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import app.thinktwice.core.Decision
import app.thinktwice.core.RuleEngine
import app.thinktwice.data.Store
import java.time.Instant
import java.time.ZoneId

/**
 * Mecanismo de intervención.
 *
 * Usa la API de accesibilidad de Android EXCLUSIVAMENTE para saber qué app pasa a primer plano
 * (evento TYPE_WINDOW_STATE_CHANGED → nombre del paquete). No lee el contenido de las ventanas
 * (canRetrieveWindowContent=false), ni texto, ni mensajes, ni pulsaciones. No es una herramienta
 * de accesibilidad para personas con discapacidad (isAccessibilityTool=false).
 *
 * Política de pausas (para evitar duplicados y bucles):
 *  - Solo se evalúa cuando cambia la app en primer plano, no en cada cambio de ventana interno.
 *  - Si se pulsa «Continuar», la app queda permitida durante el intervalo configurado. Salir y
 *    volver a entrar dentro de ese intervalo NO vuelve a mostrar la pausa.
 *  - Al terminar el intervalo, si la app sigue en primer plano, se vuelve a mostrar la pausa.
 *    Si no está en primer plano, se mostrará la próxima vez que se abra.
 *  - Si se sale sin continuar, la siguiente apertura muestra una pausa nueva (cuenta atrás completa).
 *  - No se lanza una segunda intervención para la misma app mientras la primera está visible.
 */
class GuardService : AccessibilityService() {

    companion object {
        @Volatile var instance: GuardService? = null; private set
        @Volatile var lastEventAt: Long = 0L; private set
        @Volatile var currentPkg: String? = null; private set

        /** Llamar cuando cambian reglas, sesiones o permisos concedidos desde la interfaz. */
        fun rulesChanged() { instance?.let { s -> s.handler.post { s.reevaluateCurrent() } } }

        /** La pantalla de intervención se cerró con una decisión: la siguiente apertura se evalúa de nuevo. */
        fun interventionClosed() { instance?.let { it.lastLaunchPkg = null } }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var transient: Set<String> = emptySet()
    private var lastLaunchPkg: String? = null
    private var keepAlive = false
    private var lastLaunchAt = 0L
    private val recheck = Runnable { reevaluateCurrent() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Store.init(this)
        instance = this
        transient = buildSet {
            add("com.android.systemui")
            runCatching { getSystemService(InputMethodManager::class.java).enabledInputMethodList.forEach { add(it.packageName) } }
        }
        Notifier.createChannels(this)
        Notifier.refresh(this)
        syncKeepAlive()
        // Si el proceso se reinició (p. ej. al cerrar la app desde Recientes), el sistema no
        // reenvía el evento de la app que ya estaba abierta: se recupera por estadísticas de uso.
        handler.postDelayed({ seedCurrent() }, 600)
    }

    private fun seedCurrent() {
        if (currentPkg != null) return
        val pkg = UsageRepo.foregroundNow(this) ?: return
        currentPkg = pkg
        if (pkg == packageName || pkg in Apps.essentialPackages(this) || pkg in transient) return
        evaluate(pkg)
    }

    /**
     * Mantiene el servicio en primer plano (notificación mínima) mientras haya algo que proteger.
     * Los fabricantes que limpian procesos en segundo plano respetan los servicios en primer plano.
     * Es un refuerzo: si Android no lo permite, el servicio sigue funcionando como antes.
     */
    private fun syncKeepAlive() {
        val s = Store.state.value
        val now = System.currentTimeMillis()
        val needed = s.pausedApps.isNotEmpty() ||
            s.sessions.any { it.isActive(now) } ||
            s.routines.any { it.enabled && it.packages.isNotEmpty() }
        try {
            if (needed && !keepAlive) {
                val n = Notifier.guardNotification(this)
                if (Build.VERSION.SDK_INT >= 34) startForeground(Notifier.ID_GUARD, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                else startForeground(Notifier.ID_GUARD, n)
                keepAlive = true
            } else if (!needed && keepAlive) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                keepAlive = false
            }
        } catch (e: Exception) { keepAlive = false }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        lastEventAt = System.currentTimeMillis()
        // Teclados y paneles del sistema aparecen encima sin cambiar la app en primer plano.
        if (pkg in transient) return
        val changed = pkg != currentPkg
        currentPkg = pkg
        if (pkg == packageName) return
        if (pkg in Apps.essentialPackages(this)) { handler.removeCallbacks(recheck); return }
        if (changed) evaluate(pkg)
    }

    private fun reevaluateCurrent() {
        syncKeepAlive()
        val pkg = currentPkg ?: return
        if (pkg == packageName || pkg in Apps.essentialPackages(this)) return
        evaluate(pkg)
    }

    private fun evaluate(pkg: String) {
        handler.removeCallbacks(recheck)
        val state = Store.state.value
        val now = System.currentTimeMillis()
        val zone = ZoneId.systemDefault()
        when (val d = RuleEngine.decide(state, pkg, now, zone)) {
            is Decision.Allow -> scheduleRecheck(pkg, now, zone)
            is Decision.Pause -> launch(pkg, InterventionActivity.MODE_PAUSE, 0L, null)
            is Decision.Block -> launch(pkg, InterventionActivity.MODE_BLOCK, d.untilMs,
                d.sources.joinToString(" · ") { it.name })
        }
    }

    /** Programa una única comprobación para el próximo instante en que la decisión puede cambiar. */
    private fun scheduleRecheck(pkg: String, now: Long, zone: ZoneId) {
        val s = Store.state.value
        val candidates = mutableListOf<Long>()
        s.allowances[pkg]?.takeIf { it > now }?.let { candidates += it }
        s.sessions.filter { pkg in it.packages && it.startMs > now }.forEach { candidates += it.startMs }
        val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        s.routines.filter { it.enabled && pkg in it.packages }.forEach { r ->
            for (i in 0..1) RuleEngine.windowStartingOn(r, today.plusDays(i.toLong()), zone)
                ?.first?.takeIf { it > now }?.let { candidates.add(it) }
        }
        val next = candidates.minOrNull() ?: return
        handler.postAtTime(recheck, SystemClock.uptimeMillis() + (next - now) + 300)
    }

    private fun launch(pkg: String, mode: Int, untilMs: Long, reason: String?) {
        val t = SystemClock.elapsedRealtime()
        if (pkg == lastLaunchPkg && t - lastLaunchAt < 800) return
        if (InterventionActivity.visibleFor == pkg) return
        lastLaunchPkg = pkg; lastLaunchAt = t
        try {
            startActivity(InterventionActivity.intent(this, pkg, mode, untilMs, reason))
        } catch (e: Exception) {
            // Si el sistema impide abrir la pantalla, la protección no está operativa: se informa en Diagnóstico.
            Notifier.protectionProblem(this, "Android no permitió mostrar la pantalla de pausa.")
        }
    }

    fun goHome() { performGlobalAction(GLOBAL_ACTION_HOME) }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        Notifier.refresh(this)
        super.onDestroy()
    }
}
