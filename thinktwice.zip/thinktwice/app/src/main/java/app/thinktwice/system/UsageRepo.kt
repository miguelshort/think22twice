package app.thinktwice.system

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import app.thinktwice.core.DayUsage
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.ConcurrentHashMap

/**
 * Tiempo en primer plano por app a partir de UsageStatsManager.queryEvents.
 * Solo lee qué app estaba en primer plano y cuándo; nunca contenido.
 *
 * Limitaciones: Android conserva el historial detallado de eventos un número limitado de días
 * (varía según versión y fabricante). Los días sin eventos se devuelven como null
 * ("sin datos"), nunca como 0.
 */
object UsageRepo {
    private const val RESUMED = 1   // UsageEvents.Event.ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
    private const val PAUSED = 2    // ACTIVITY_PAUSED / MOVE_TO_BACKGROUND
    private const val STOPPED = 23  // ACTIVITY_STOPPED (API 29+)

    private val pastCache = ConcurrentHashMap<String, Map<String, Long>>()

    fun day(context: Context, date: LocalDate, zone: ZoneId = ZoneId.systemDefault()): DayUsage? {
        if (!Perms.hasUsageAccess(context)) return null
        val today = LocalDate.now(zone)
        val key = "$date@$zone"
        if (date.isBefore(today)) pastCache[key]?.let { return it.takeIf { m -> m.isNotEmpty() } }
        val start = date.atStartOfDay(zone).toInstant().toEpochMilli()
        val end = minOf(date.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli(), System.currentTimeMillis())
        if (end <= start) return null
        val result = compute(context, start, end)
        if (date.isBefore(today)) pastCache[key] = result ?: emptyMap()
        return result
    }

    fun range(context: Context, from: LocalDate, days: Int): List<Pair<LocalDate, DayUsage?>> =
        (0 until days).map { from.plusDays(it.toLong()) }.map { it to day(context, it) }

    private fun compute(context: Context, start: Long, end: Long): DayUsage? {
        val usm = context.getSystemService(UsageStatsManager::class.java) ?: return null
        val ignore = Apps.essentialPackages(context) - setOf(context.packageName)
        val events = try { usm.queryEvents(start - 3 * 3600_000L, end) } catch (e: Exception) { return null }
        val fgSince = HashMap<String, Long>()
        val totals = HashMap<String, Long>()
        var any = false
        val ev = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            val pkg = ev.packageName ?: continue
            val t = ev.timeStamp
            when (ev.eventType) {
                RESUMED -> { if (t >= start) any = true; fgSince[pkg] = t }
                PAUSED, STOPPED -> {
                    val s = fgSince.remove(pkg) ?: continue
                    if (t >= start) any = true
                    add(totals, pkg, maxOf(s, start), minOf(t, end))
                }
            }
        }
        // Apps todavía en primer plano al final del intervalo.
        fgSince.forEach { (pkg, s) -> if (end - s < 6 * 3600_000L) add(totals, pkg, maxOf(s, start), end) }
        if (!any && totals.isEmpty()) return null
        return totals.filterKeys { it !in ignore && it != context.packageName }.filterValues { it >= 1000 }
    }

    private fun add(m: HashMap<String, Long>, pkg: String, a: Long, b: Long) {
        if (b > a) m[pkg] = (m[pkg] ?: 0L) + (b - a)
    }

    fun clearCache() = pastCache.clear()

    /**
     * App en primer plano ahora mismo según los eventos de uso (últimos minutos), o null.
     * Se usa al reconectarse el servicio tras cerrarse el proceso: el sistema no reenvía el
     * evento de la app que ya estaba abierta, y sin esto esa app quedaría sin evaluar.
     */
    fun foregroundNow(context: Context): String? {
        if (!Perms.hasUsageAccess(context)) return null
        val usm = context.getSystemService(UsageStatsManager::class.java) ?: return null
        val now = System.currentTimeMillis()
        val events = try { usm.queryEvents(now - 10 * 60_000L, now) } catch (e: Exception) { return null }
        var current: String? = null
        val ev = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            val pkg = ev.packageName ?: continue
            when (ev.eventType) {
                RESUMED -> current = pkg
                PAUSED, STOPPED -> if (current == pkg) current = null
            }
        }
        return current
    }
}
