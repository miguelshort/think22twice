package app.thinktwice.ui.theme

import android.provider.Settings
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

/** true cuando el usuario ha pedido reducir el movimiento (en el sistema o en thinktwice). */
val LocalReduceMotion = compositionLocalOf { false }

@Composable
fun <T> ttTween(ms: Int): FiniteAnimationSpec<T> = if (LocalReduceMotion.current) snap() else tween(ms)

@Composable
fun ThinkTwiceTheme(reduceMotionPref: Boolean? = null, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val systemReduced = remember {
        Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }
    val scheme = darkColorScheme(
        primary = TT.Accent, onPrimary = TT.Bg,
        background = TT.Bg, onBackground = TT.Text,
        surface = TT.Surface, onSurface = TT.Text,
        surfaceVariant = TT.Card, onSurfaceVariant = TT.TextSecondary,
        surfaceContainer = TT.Card, surfaceContainerHigh = TT.Control, surfaceContainerLow = TT.Surface,
        secondaryContainer = TT.Control, onSecondaryContainer = TT.Text,
        error = TT.Danger, outline = TT.Control, outlineVariant = TT.Divider,
    )
    val typo = Typography(
        bodyLarge = Type.body, bodyMedium = Type.body.copy(fontSize = Type.secondary.fontSize),
        labelLarge = Type.button, titleLarge = Type.section, headlineMedium = Type.screenTitle,
    )
    CompositionLocalProvider(LocalReduceMotion provides (reduceMotionPref ?: systemReduced)) {
        MaterialTheme(colorScheme = scheme, typography = typo, content = content)
    }
}
