package app.thinktwice.system

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.thinktwice.MainActivity
import app.thinktwice.core.EventType
import app.thinktwice.core.Fmt
import app.thinktwice.data.Store
import app.thinktwice.ui.components.*
import app.thinktwice.ui.theme.*
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * Pantalla de intervención (pausa consciente o restricción). Se abre desde [GuardService]
 * encima de la app que se intentaba abrir, en su propia tarea y fuera de Recientes.
 */
class InterventionActivity : ComponentActivity() {

    companion object {
        const val MODE_PAUSE = 0
        const val MODE_BLOCK = 1
        private const val X_PKG = "pkg"; private const val X_MODE = "mode"; private const val X_UNTIL = "until"; private const val X_REASON = "reason"
        @Volatile var visibleFor: String? = null; private set

        fun intent(c: Context, pkg: String, mode: Int, untilMs: Long, reason: String?) =
            Intent(c, InterventionActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                .putExtra(X_PKG, pkg).putExtra(X_MODE, mode).putExtra(X_UNTIL, untilMs).putExtra(X_REASON, reason)
    }

    private data class Params(val pkg: String, val mode: Int, val until: Long, val reason: String?, val startedAt: Long)

    private var params by mutableStateOf<Params?>(null)
    private var decided = false

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        Store.init(this)
        val started = savedInstanceState?.getLong("startedAt") ?: SystemClock.elapsedRealtime()
        load(intent, started, logIt = savedInstanceState == null)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() = exit() })
        setContent {
            val s by Store.state.collectAsState()
            ThinkTwiceTheme(s.settings.reduceMotion) {
                params?.let { p ->
                    InterventionScreen(
                        pkg = p.pkg, block = p.mode == MODE_BLOCK, untilMs = p.until, reason = p.reason,
                        startedAt = p.startedAt, waitSeconds = s.settings.waitSeconds, allowedMinutes = s.settings.allowedMinutes,
                        messages = s.messages.map { it.text },
                        onExit = ::exit, onContinue = ::continueToApp,
                        onOpenApp = { decided = true; startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); finish() },
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val p = params
        // Misma app y mismo modo: se mantiene la cuenta atrás en curso (sin duplicar la intervención).
        if (p != null && p.pkg == intent.getStringExtra(X_PKG) && p.mode == intent.getIntExtra(X_MODE, 0)) return
        decided = false
        load(intent, SystemClock.elapsedRealtime(), logIt = true)
    }

    private fun load(i: Intent, started: Long, logIt: Boolean) {
        val pkg = i.getStringExtra(X_PKG) ?: run { finish(); return }
        val mode = i.getIntExtra(X_MODE, MODE_PAUSE)
        params = Params(pkg, mode, i.getLongExtra(X_UNTIL, 0L), i.getStringExtra(X_REASON), started)
        if (logIt) Store.log(if (mode == MODE_BLOCK) EventType.BLOCK_SHOWN else EventType.PAUSE_SHOWN, pkg)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        params?.let { outState.putLong("startedAt", it.startedAt) }
    }

    override fun onStart() { super.onStart(); visibleFor = params?.pkg }

    override fun onStop() {
        super.onStop()
        visibleFor = null
        // Si se abandona la pantalla sin decidir (botón Inicio, otra app), cuenta como no continuar.
        if (!decided && !isChangingConfigurations) {
            decided = true
            if (params?.mode == MODE_PAUSE) Store.log(EventType.EXITED, params?.pkg)
            finish()
        }
    }

    private fun exit() {
        GuardService.interventionClosed()
        if (!decided) { decided = true; if (params?.mode == MODE_PAUSE) Store.log(EventType.EXITED, params?.pkg) }
        GuardService.instance?.goHome() ?: startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    private fun continueToApp() {
        val p = params ?: return
        if (decided) return
        decided = true
        GuardService.interventionClosed()
        val until = System.currentTimeMillis() + Store.state.value.settings.allowedMinutes * 60_000L
        Store.update { it.copy(allowances = it.allowances + (p.pkg to until)) }
        Store.log(EventType.CONTINUED, p.pkg)
        finish()
    }
}

@Composable
private fun InterventionScreen(
    pkg: String, block: Boolean, untilMs: Long, reason: String?, startedAt: Long,
    waitSeconds: Int, allowedMinutes: Int, messages: List<String>,
    onExit: () -> Unit, onContinue: () -> Unit, onOpenApp: () -> Unit,
) {
    val message = rememberSaveable(pkg, startedAt) { messages.randomOrNull() ?: "¿Qué venías a hacer aquí?" }
    val now by produceState(SystemClock.elapsedRealtime(), startedAt) {
        while (true) { value = SystemClock.elapsedRealtime(); delay(200) }
    }
    val wall by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
    val remaining = (waitSeconds * 1000L - (now - startedAt)).coerceAtLeast(0)
    val label = appLabel(pkg)

    Column(
        Modifier.fillMaxSize().background(TT.Bg).systemBarsPadding().padding(horizontal = Dim.screenH, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Logo(20.dp, Modifier.padding(top = 8.dp))
        Spacer(Modifier.weight(1f))
        Box(contentAlignment = Alignment.BottomEnd) {
            AppIcon(pkg, 64.dp)
            if (block) Box(Modifier.size(26.dp).background(TT.Danger, androidx.compose.foundation.shape.CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Lock, null, tint = TT.Bg, modifier = Modifier.size(14.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(label, style = Type.secondary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(Dim.section))
        if (!block) {
            Text(message, style = Type.screenTitle, textAlign = TextAlign.Center)
            Spacer(Modifier.height(Dim.section))
            val secs = (remaining + 999) / 1000
            Text(if (secs >= 60) Fmt.countdown(remaining) else "$secs",
                style = Type.countdown, textAlign = TextAlign.Center,
                modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
            Text(if (remaining > 0) if (secs >= 60) "de pausa" else "segundos de pausa" else "Tú decides", style = Type.secondary)
        } else {
            val until = Instant.ofEpochMilli(untilMs).atZone(ZoneId.systemDefault())
            val sameDay = until.toLocalDate() == java.time.LocalDate.now()
            val fmt = DateTimeFormatter.ofPattern(if (sameDay) "HH:mm" else "EEE d, HH:mm", java.util.Locale("es"))
            Text("$label está en pausa ahora", style = Type.screenTitle, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text("Motivo: ${reason ?: "restricción activa"}", style = Type.body.copy(color = TT.TextSecondary), textAlign = TextAlign.Center)
            Spacer(Modifier.height(Dim.section))
            Text(Fmt.countdown(untilMs - wall), style = Type.countdown.copy(fontSize = Type.hero.fontSize), textAlign = TextAlign.Center)
            Text("Disponible a las ${until.format(fmt)}", style = Type.secondary)
            Spacer(Modifier.height(16.dp))
            Text("Es una restricción de thinktwice, no del sistema: puedes terminarla con la salida de emergencia dentro de la app.",
                style = Type.label, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.weight(1f))
        PillButton("Salir", onExit, Modifier.fillMaxWidth())
        Spacer(Modifier.height(Dim.related))
        if (!block) {
            PillButton(
                if (remaining > 0) "Continuar" else "Continuar $allowedMinutes min",
                onContinue, Modifier.fillMaxWidth(), tone = ButtonTone.Secondary, enabled = remaining == 0L,
            )
        } else {
            PillButton("Abrir thinktwice", onOpenApp, Modifier.fillMaxWidth(), tone = ButtonTone.Secondary)
        }
    }
}
