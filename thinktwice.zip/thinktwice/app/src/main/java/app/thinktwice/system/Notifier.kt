package app.thinktwice.system

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import app.thinktwice.MainActivity
import app.thinktwice.R
import app.thinktwice.core.*
import app.thinktwice.data.Store
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * Notificaciones locales: estado de sesiones activas y recordatorios opcionales de retos.
 * No se usa ningún servidor. En Android no existe Dynamic Island: se usa una notificación
 * normal con cuenta atrás del sistema.
 */
object Notifier {
    private const val CH_SESSION = "sessions"
    private const val CH_REMINDER = "reminders"
    private const val CH_ALERT = "alerts"
    private const val ID_SESSION = 10
    private const val ID_PROBLEM = 11
    private const val ID_REMINDER = 12
    private val hhmm = DateTimeFormatter.ofPattern("HH:mm")

    fun createChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SESSION, "Sesiones activas", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_REMINDER, "Recordatorios de retos", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Avisos de protección", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun canPost(c: Context) = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun openApp(c: Context) = PendingIntent.getActivity(
        c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    /** Vuelve a calcular la notificación de sesión a partir de las marcas de tiempo guardadas. */
    fun refresh(c: Context) {
        Store.init(c)
        val s = Store.state.value
        val now = System.currentTimeMillis()
        val nm = NotificationManagerCompat.from(c)
        val active = s.sessions.filter { it.isActive(now) }
        scheduleNextRefresh(c, active.minOfOrNull { it.endMs })
        if (active.isEmpty() || !s.settings.sessionNotifications || !canPost(c)) { nm.cancel(ID_SESSION); return }
        val ends = active.maxOf { it.endMs }
        val operative = Perms.isGuardEnabled(c)
        val title = if (active.size == 1) active[0].name else "${active.size} sesiones activas"
        val endText = java.time.Instant.ofEpochMilli(ends).atZone(ZoneId.systemDefault()).format(hhmm)
        val text = if (operative) "Hasta las $endText · ${active.flatMap { it.packages }.toSet().size} apps"
        else "Protección no operativa: activa el servicio de thinktwice en Accesibilidad"
        val n = NotificationCompat.Builder(c, CH_SESSION)
            .setSmallIcon(R.drawable.ic_stat_tt)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setWhen(ends).setUsesChronometer(true).setChronometerCountDown(true).setShowWhen(true)
            .setTimeoutAfter((ends - now).coerceAtLeast(1000))
            .setContentIntent(openApp(c))
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .build()
        try { nm.notify(ID_SESSION, n) } catch (_: SecurityException) {}
    }

    fun protectionProblem(c: Context, message: String) {
        if (!canPost(c)) return
        val n = NotificationCompat.Builder(c, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_tt)
            .setContentTitle("Protección no operativa")
            .setContentText(message)
            .setContentIntent(openApp(c))
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(c).notify(ID_PROBLEM, n) } catch (_: SecurityException) {}
    }

    private fun scheduleNextRefresh(c: Context, at: Long?) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(c, 1, Intent(c, RefreshReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        am.cancel(pi)
        // Alarma inexacta: basta con retirar la notificación aproximadamente a su hora.
        if (at != null) am.setAndAllowWhileIdle(AlarmManager.RTC, at + 1000, pi)
    }

    /** Programa el próximo recordatorio diario de retos (si hay alguno con recordatorio). */
    fun scheduleReminder(c: Context) {
        val s = Store.state.value
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(c, 2, Intent(c, ReminderReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        am.cancel(pi)
        val today = LocalDate.now()
        val wanted = s.challenges.any { ch -> ch.reminder && !ch.archived && Challenges.days(ch).last() >= today }
        if (!wanted) return
        val zone = ZoneId.systemDefault()
        var at = LocalDateTime.of(today, java.time.LocalTime.of(s.settings.reminderHour, 0)).atZone(zone)
        if (at.toInstant().toEpochMilli() <= System.currentTimeMillis()) at = at.plusDays(1)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at.toInstant().toEpochMilli(), pi)
    }

    fun showReminder(c: Context) {
        if (!canPost(c)) return
        val n = NotificationCompat.Builder(c, CH_REMINDER)
            .setSmallIcon(R.drawable.ic_stat_tt)
            .setContentTitle("Tu reto de hoy")
            .setContentText("Revisa cómo va tu compromiso de hoy en thinktwice.")
            .setContentIntent(openApp(c))
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(c).notify(ID_REMINDER, n) } catch (_: SecurityException) {}
    }
}

class RefreshReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Notifier.refresh(c); GuardService.rulesChanged() }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.init(c); Notifier.showReminder(c); Notifier.scheduleReminder(c)
    }
}

/** Reinicio del móvil, actualización de la app o cambio de hora/zona: se recalcula todo. */
class SystemEventsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.init(c)
        UsageRepo.clearCache()
        Notifier.createChannels(c)
        Notifier.refresh(c)
        Notifier.scheduleReminder(c)
        GuardService.rulesChanged()
    }
}
