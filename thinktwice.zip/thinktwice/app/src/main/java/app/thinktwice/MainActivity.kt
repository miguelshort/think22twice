package app.thinktwice

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import app.thinktwice.data.Store
import app.thinktwice.system.GuardService
import app.thinktwice.system.Notifier
import app.thinktwice.ui.AppRoot
import app.thinktwice.ui.theme.ThinkTwiceTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.launch

class ThinkTwiceApp : Application() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Notifier.createChannels(this)
        // Cada cambio de reglas recalcula notificaciones y la decisión de la app en primer plano.
        scope.launch {
            Store.state.distinctUntilChangedBy { Triple(it.sessions, it.routines, it.routineSkips) to (it.pausedApps to it.settings.sessionNotifications) }
                .collect { Notifier.refresh(this@ThinkTwiceApp); GuardService.rulesChanged() }
        }
        scope.launch {
            Store.state.distinctUntilChangedBy { it.challenges to it.settings.reminderHour }
                .collect { Notifier.scheduleReminder(this@ThinkTwiceApp) }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val state by Store.state.collectAsState()
            ThinkTwiceTheme(state.settings.reduceMotion) { AppRoot(state) }
        }
    }
}
