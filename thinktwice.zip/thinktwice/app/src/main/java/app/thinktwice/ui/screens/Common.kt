package app.thinktwice.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import app.thinktwice.core.DayUsage
import app.thinktwice.system.Apps
import app.thinktwice.system.InstalledApp
import app.thinktwice.system.UsageRepo
import app.thinktwice.ui.LocalNav
import app.thinktwice.ui.LocalResumeTick
import app.thinktwice.ui.components.*
import app.thinktwice.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

/** Estructura de pantalla de detalle: botón Atrás, título destacado y contenido desplazable. */
@Composable
fun DetailScaffold(
    title: String,
    actions: @Composable RowScope.() -> Unit = {},
    content: LazyListScope.() -> Unit,
) {
    val nav = LocalNav.current
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Volver", { nav.pop() }, bg = TT.Bg)
            Spacer(Modifier.weight(1f))
            actions()
        }
        LazyColumn(
            Modifier.fillMaxSize(), state = rememberLazyListState(),
            contentPadding = PaddingValues(start = Dim.screenH, end = Dim.screenH, bottom = 40.dp),
        ) {
            item { Text(title, style = Type.screenTitle, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)) }
            content()
            item { Spacer(Modifier.navigationBarsPadding()) }
        }
    }
}

/** Uso real de un día; null = sin permiso o sin datos. Se recarga al volver a la app. */
@Composable
fun rememberDayUsage(date: LocalDate): State<UsageResult> {
    val ctx = LocalContext.current
    val tick = LocalResumeTick.current
    return produceState<UsageResult>(UsageResult.Loading, date, tick) {
        value = withContext(Dispatchers.IO) { UsageResult.Done(UsageRepo.day(ctx, date)) }
    }
}

@Composable
fun rememberRangeUsage(from: LocalDate, days: Int): State<RangeResult> {
    val ctx = LocalContext.current
    val tick = LocalResumeTick.current
    return produceState<RangeResult>(RangeResult.Loading, from, days, tick) {
        value = withContext(Dispatchers.IO) { RangeResult.Done(UsageRepo.range(ctx, from, days)) }
    }
}

sealed interface UsageResult { data object Loading : UsageResult; data class Done(val usage: DayUsage?) : UsageResult }
sealed interface RangeResult { data object Loading : RangeResult; data class Done(val days: List<Pair<LocalDate, DayUsage?>>) : RangeResult }

@Composable
fun rememberInstalledApps(): State<List<InstalledApp>?> {
    val ctx = LocalContext.current
    return produceState<List<InstalledApp>?>(null) { value = withContext(Dispatchers.IO) { Apps.launchable(ctx) } }
}

/** Selector de aplicaciones con búsqueda (las esenciales del sistema no aparecen). */
@Composable
fun AppPickerSheet(title: String, initial: Set<String>, onDismiss: () -> Unit, onDone: (Set<String>) -> Unit) {
    var selected by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf("") }
    val apps by rememberInstalledApps()
    TTSheet(onDismiss, title, primary = "Guardar (${selected.size})", onPrimary = { onDone(selected) }) {
        LabeledField("Buscar", query, { query = it }, placeholder = "Nombre de la app")
        Spacer(Modifier.height(12.dp))
        val list = apps
        if (list == null) {
            Text("Cargando aplicaciones…", style = Type.secondary, modifier = Modifier.padding(vertical = 24.dp))
        } else {
            val filtered = list.filter { query.isBlank() || it.label.contains(query.trim(), ignoreCase = true) }
                .sortedByDescending { it.pkg in initial }
            ListGroup {
                filtered.forEachIndexed { i, app ->
                    if (i > 0) RowDivider()
                    val checked = app.pkg in selected
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 60.dp)
                            .pressable(role = Role.Checkbox, scaleDown = false) { selected = if (checked) selected - app.pkg else selected + app.pkg }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AppIcon(app.pkg)
                        Spacer(Modifier.width(14.dp))
                        Text(app.label, style = Type.bodyMedium, modifier = Modifier.weight(1f), maxLines = 2)
                        Checkbox(checked, null, colors = CheckboxDefaults.colors(checkedColor = TT.Accent, uncheckedColor = TT.TextSecondary, checkmarkColor = TT.Bg))
                    }
                }
                if (filtered.isEmpty()) Text("Ninguna app coincide.", style = Type.secondary, modifier = Modifier.padding(16.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text("Ajustes, teléfono, teclado, lanzador y la interfaz del sistema no se pueden seleccionar.", style = Type.label)
        }
    }
}

/** Fila de app con tiempo de uso a la derecha. */
@Composable
fun AppUsageRow(pkg: String, ms: Long, classLabel: String, onClick: (() -> Unit)?) {
    ListRow(
        title = appLabel(pkg), subtitle = classLabel,
        leading = { AppIcon(pkg) }, value = app.thinktwice.core.Fmt.duration(ms), onClick = onClick,
    )
}

fun classLabel(c: app.thinktwice.core.AppClass?) = when (c) {
    app.thinktwice.core.AppClass.USEFUL -> "Útil"
    app.thinktwice.core.AppClass.DISTRACTING -> "Distractora"
    app.thinktwice.core.AppClass.NEUTRAL -> "Neutra"
    null -> "Sin clasificar"
}

fun appsSummary(count: Int) = when (count) { 0 -> "Ninguna app"; 1 -> "1 app"; else -> "$count apps" }
