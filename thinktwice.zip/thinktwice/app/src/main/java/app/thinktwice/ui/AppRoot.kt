package app.thinktwice.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home as HomeOutlined
import androidx.compose.material.icons.outlined.Lock as LockOutlined
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.thinktwice.core.AppState
import app.thinktwice.ui.components.pressable
import app.thinktwice.ui.screens.*
import app.thinktwice.ui.theme.*
import kotlinx.coroutines.delay

/** Destinos de detalle (se apilan sobre las pestañas con desplazamiento horizontal). */
sealed interface Dest {
    data object Stats : Dest
    data object Settings : Dest
    data object Profile : Dest
    data object Diagnostics : Dest
    data object Messages : Dest
    data object Templates : Dest
    data object Classify : Dest
    data object Sessions : Dest
    data object About : Dest
    data class RoutineEdit(val id: String?, val exampleId: String? = null) : Dest
    data class ChallengeDetail(val id: String) : Dest
}

enum class SheetKind { Block, Pause, NewChallenge }

class Nav {
    val stack = mutableStateListOf<Dest>()
    var forward by mutableStateOf(true); private set
    var sheet by mutableStateOf<SheetKind?>(null)
    var toast by mutableStateOf<String?>(null)
    var tab by mutableIntStateOf(0)
    fun push(d: Dest) { forward = true; stack.add(d) }
    fun pop() { forward = false; if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }
    fun popTo(n: Int) { forward = false; while (stack.size > n) stack.removeAt(stack.lastIndex) }
    fun show(msg: String) { toast = msg }
}

val LocalNav = staticCompositionLocalOf<Nav> { error("Nav no disponible") }
/** Se incrementa cada vez que la app vuelve a primer plano (permisos y datos de uso actualizados). */
val LocalResumeTick = compositionLocalOf { 0 }

@Composable
fun AppRoot(state: AppState) {
    val nav = remember { Nav() }
    var resumeTick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) resumeTick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }

    CompositionLocalProvider(LocalNav provides nav, LocalResumeTick provides resumeTick) {
        Box(Modifier.fillMaxSize().background(TT.Bg)) {
            if (!state.settings.onboardingDone) {
                OnboardingScreen(state)
                return@Box
            }
            Tabs(state, nav)
            DetailLayer(state, nav)
            when (nav.sheet) {
                SheetKind.Block -> BlockSheet(state) { nav.sheet = null }
                SheetKind.Pause -> PauseSheet(state) { nav.sheet = null }
                SheetKind.NewChallenge -> NewChallengeSheet(state) { nav.sheet = null }
                null -> Unit
            }
            Toast(nav)
        }
    }
}

@Composable
private fun Tabs(state: AppState, nav: Nav) {
    val holder = rememberSaveableStateHolder()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(nav.tab) { tab = nav.tab }
    val reduce = LocalReduceMotion.current
    Column(Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = tab, modifier = Modifier.weight(1f),
            transitionSpec = {
                if (reduce) EnterTransition.None togetherWith ExitTransition.None
                else fadeIn(tween(Motion.tab)) togetherWith fadeOut(tween(Motion.tab))
            }, label = "tabs",
        ) { t ->
            holder.SaveableStateProvider(t) {
                if (t == 0) HomeScreen(state) else RoutinesScreen(state)
            }
        }
        BottomBar(selected = if (nav.sheet == SheetKind.Block) 2 else tab) { i ->
            when (i) {
                2 -> nav.sheet = SheetKind.Block // Bloquear abre el panel; al cerrarlo vuelve la pestaña de origen.
                else -> { tab = i; nav.tab = i }
            }
        }
    }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        Triple("Inicio", Icons.Rounded.Home, Icons.Outlined.HomeOutlined),
        Triple("Rutinas", Icons.Rounded.EventRepeat, Icons.Rounded.EventRepeat),
        Triple("Bloquear", Icons.Rounded.Lock, Icons.Outlined.LockOutlined),
    )
    Column(Modifier.fillMaxWidth().background(TT.Surface)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(TT.Divider))
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(64.dp)) {
            items.forEachIndexed { i, (label, activeIcon, idleIcon) ->
                val sel = i == selected
                Column(
                    Modifier.weight(1f).fillMaxHeight()
                        .pressable(role = Role.Tab, scaleDown = false) { onSelect(i) }
                        .semantics { this.selected = sel },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                ) {
                    Icon(if (sel) activeIcon else idleIcon, null, tint = if (sel) TT.Text else TT.TextSecondary, modifier = Modifier.size(Dim.icon))
                    Spacer(Modifier.height(4.dp))
                    Text(label, style = if (sel) Type.label.copy(color = TT.Text, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold) else Type.label)
                }
            }
        }
    }
}


@Composable
private fun DetailLayer(state: AppState, nav: Nav) {
    val holder = rememberSaveableStateHolder()
    val reduce = LocalReduceMotion.current
    BackHandler(enabled = nav.stack.isNotEmpty() && nav.sheet == null) { nav.pop() }
    AnimatedContent(
        targetState = nav.stack.lastOrNull() to nav.stack.size,
        transitionSpec = {
            if (reduce) EnterTransition.None togetherWith ExitTransition.None
            else if (nav.forward) slideInHorizontally(tween(Motion.detail)) { it / 3 } + fadeIn(tween(Motion.detail)) togetherWith
                fadeOut(tween(Motion.detail / 2))
            else fadeIn(tween(Motion.detail / 2)) togetherWith
                slideOutHorizontally(tween(Motion.detail)) { it / 3 } + fadeOut(tween(Motion.detail))
        },
        contentKey = { it.second }, label = "detail",
    ) { (dest, depth) ->
        if (dest == null) return@AnimatedContent
        holder.SaveableStateProvider("$depth:$dest") {
            Box(Modifier.fillMaxSize().background(TT.Bg)) {
                when (dest) {
                    Dest.Stats -> StatsScreen(state)
                    Dest.Settings -> SettingsScreen(state)
                    Dest.Profile -> ProfileScreen(state)
                    Dest.Diagnostics -> DiagnosticsScreen(state)
                    Dest.Messages -> MessagesScreen(state)
                    Dest.Templates -> TemplatesScreen(state)
                    Dest.Classify -> ClassifyScreen(state)
                    Dest.Sessions -> SessionsScreen(state)
                    Dest.About -> AboutScreen()
                    is Dest.RoutineEdit -> RoutineEditorScreen(state, dest)
                    is Dest.ChallengeDetail -> ChallengeDetailScreen(state, dest.id)
                }
            }
        }
    }
}

@Composable
private fun BoxScope.Toast(nav: Nav) {
    val msg = nav.toast
    LaunchedEffect(msg) { if (msg != null) { delay(2600); nav.toast = null } }
    AnimatedVisibility(
        visible = msg != null, enter = fadeIn(tween(160)) + slideInVertically(tween(200)) { it / 2 }, exit = fadeOut(tween(160)),
        modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 80.dp, start = 20.dp, end = 20.dp),
    ) {
        Row(
            Modifier.clip(CircleShape).background(TT.Control).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.CheckCircle, null, tint = TT.Positive, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(msg ?: "", style = Type.bodyMedium)
        }
    }
}
