package app.thinktwice.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.thinktwice.core.*
import app.thinktwice.data.Store
import app.thinktwice.system.Perms
import app.thinktwice.ui.Dest
import app.thinktwice.ui.LocalNav
import app.thinktwice.ui.LocalResumeTick
import app.thinktwice.ui.SheetKind
import app.thinktwice.ui.components.*
import app.thinktwice.ui.theme.*
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val es = Locale("es", "ES")

@Composable
fun HomeScreen(state: AppState) {
    val nav = LocalNav.current
    val ctx = LocalContext.current
    val tick = LocalResumeTick.current
    val zone = ZoneId.systemDefault()
    var offset by rememberSaveable { mutableIntStateOf(0) }
    val date = LocalDate.now(zone).minusDays(offset.toLong())
    val usage by rememberDayUsage(date)
    val hasUsage = remember(tick) { Perms.hasUsageAccess(ctx) }
    val guardOn = remember(tick) { Perms.isGuardEnabled(ctx) }
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
    val activeSessions = state.sessions.filter { it.isActive(now) }
    val activeRoutines = RuleEngine.restrictionsAt(state, now, zone).filter { it.kind == Restriction.Kind.ROUTINE }
    val needsGuard = state.pausedApps.isNotEmpty() || activeSessions.isNotEmpty() || state.routines.any { it.enabled }
    var confirmEnd by remember { mutableStateOf<BlockSession?>(null) }
    val haptic = rememberHaptic()

    LazyColumn(
        Modifier.fillMaxSize().background(Brush.verticalGradient(0f to TT.HeroTop, 0.45f to TT.Bg)),
        state = rememberLazyListState(),
        contentPadding = PaddingValues(start = Dim.screenH, end = Dim.screenH, bottom = 24.dp),
    ) {
        item {
            // Cabecera: perfil a la izquierda, logo discreto, estadísticas y ajustes a la derecha.
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(Dim.touch).pressable { nav.push(Dest.Profile) }.semantics { contentDescription = "Perfil" },
                    contentAlignment = Alignment.Center,
                ) {
                    Box(Modifier.size(40.dp).clip(CircleShape).background(TT.Control), contentAlignment = Alignment.Center) {
                        val initial = state.settings.name.trim().firstOrNull()?.uppercase()
                        if (initial != null) Text(initial, style = Type.cardTitle)
                        else Icon(Icons.Rounded.Person, null, tint = TT.Text, modifier = Modifier.size(20.dp))
                    }
                }
                Spacer(Modifier.weight(1f))
                Logo(16.dp)
                Spacer(Modifier.weight(1f))
                CircleIconButton(Icons.Rounded.BarChart, "Estadísticas", { nav.push(Dest.Stats) })
                CircleIconButton(Icons.Rounded.Settings, "Ajustes", { nav.push(Dest.Settings) })
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(top = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                val label = if (offset == 0) "Tiempo de uso hoy" else "Tiempo de uso · " + date.format(DateTimeFormatter.ofPattern("EEEE d MMM", es))
                Text(label, style = Type.secondary)
                Spacer(Modifier.height(4.dp))
                when (val u = usage) {
                    UsageResult.Loading -> Text("…", style = Type.hero)
                    is UsageResult.Done -> HeroDuration(u.usage?.values?.sum())
                }
                if (!hasUsage) Text("Sin permiso de uso", style = Type.label.copy(color = TT.Danger))
                else if ((usage as? UsageResult.Done)?.usage == null) Text("Sin datos registrados para este día", style = Type.label)
                Spacer(Modifier.height(14.dp))
                // Selector compacto de fecha.
                Row(Modifier.clip(CircleShape).background(TT.Control), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).pressable(enabled = offset < 29) { offset++ }.semantics { contentDescription = "Día anterior" }, contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, null, tint = if (offset < 29) TT.Text else TT.TextSecondary)
                    }
                    Text(when (offset) { 0 -> "Hoy"; 1 -> "Ayer"; else -> date.format(DateTimeFormatter.ofPattern("d MMM", es)) },
                        style = Type.button.copy(fontSize = Type.secondary.fontSize), modifier = Modifier.widthIn(min = 64.dp), textAlign = TextAlign.Center)
                    Box(Modifier.size(40.dp).pressable(enabled = offset > 0) { offset-- }.semantics { contentDescription = "Día siguiente" }, contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = if (offset > 0) TT.Text else TT.TextSecondary)
                    }
                }
                Spacer(Modifier.height(28.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    QuickAction(Icons.Rounded.HourglassTop, "Pausa", { nav.sheet = SheetKind.Pause })
                    QuickAction(Icons.Rounded.Lock, "Bloquear", { nav.sheet = SheetKind.Block })
                    QuickAction(Icons.Rounded.Add, "Nueva rutina", { nav.push(Dest.RoutineEdit(null)) })
                }
            }
        }
        if (needsGuard && !guardOn) item {
            Spacer(Modifier.height(Dim.section))
            Banner(BannerKind.Error, "Protección no operativa",
                "Tus pausas y bloqueos no pueden mostrarse hasta activar el servicio de thinktwice en Accesibilidad.",
                "Revisar diagnóstico") { nav.push(Dest.Diagnostics) }
        }
        if (activeSessions.isNotEmpty() || activeRoutines.isNotEmpty()) {
            item { SectionHeader("Ahora") }
            items(activeSessions, key = { it.id }) { s ->
                ActiveCard(s.name, "Sesión de bloqueo", s.packages, s.endMs - now, guardOn,
                    action = "Terminar", onAction = { confirmEnd = s })
                Spacer(Modifier.height(Dim.related))
            }
            items(activeRoutines, key = { "r" + it.id }) { r ->
                ActiveCard(r.name, "Rutina", r.packages, r.endMs - now, guardOn, onClick = { nav.push(Dest.RoutineEdit(r.id)) })
                Spacer(Modifier.height(Dim.related))
            }
        }
        item {
            SectionHeader("Productividad", "Desglose") { nav.push(Dest.Stats) }
            val pct = (usage as? UsageResult.Done)?.usage?.let { Productivity.percent(it, state.classes) }
            TTCard(onClick = { nav.push(Dest.Stats) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Ring(pct, size = 96.dp, stroke = 9.dp)
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (pct == null) "Sin datos suficientes" else "Uso clasificado como útil", style = Type.cardTitle)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (pct == null) "Clasifica tus apps como útiles o distractoras para calcularlo."
                            else "Útiles ÷ (útiles + distractoras). Neutras y sin clasificar no cuentan.",
                            style = Type.secondary,
                        )
                    }
                }
            }
        }
        item {
            SectionHeader("Próxima rutina")
            val next = RuleEngine.nextRoutineStart(state, now, zone)
            if (next == null) EmptyState(Icons.Rounded.EventRepeat, "Sin rutinas programadas", "Crea una rutina para proteger franjas del día.", "Nueva rutina") { nav.push(Dest.RoutineEdit(null)) }
            else {
                val (r, w) = next
                val start = Instant.ofEpochMilli(w.first).atZone(zone)
                val day = when (start.toLocalDate()) { LocalDate.now(zone) -> "Hoy"; LocalDate.now(zone).plusDays(1) -> "Mañana"; else -> start.format(DateTimeFormatter.ofPattern("EEEE", es)).replaceFirstChar { it.uppercase() } }
                TTCard(onClick = { nav.push(Dest.RoutineEdit(r.id)) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RowIcon(routineIcon(r.icon))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.name, style = Type.cardTitle)
                            Text("$day · ${Fmt.clock(r.startMin)} – ${Fmt.clock(r.endMin)}", style = Type.secondary)
                        }
                        AppStack(r.packages, 3)
                    }
                }
            }
        }
        item {
            SectionHeader("Actividad", "Ver todo") { nav.push(Dest.Stats) }
            val dayStart = date.atStartOfDay(zone).toInstant().toEpochMilli()
            val dayEnd = date.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
            val ev = state.events.filter { it.t in dayStart until dayEnd }
            val pauses = ev.count { it.type == EventType.PAUSE_SHOWN }
            val notContinued = ev.count { it.type == EventType.EXITED }
            val blocked = ev.count { it.type == EventType.BLOCK_SHOWN }
            TTCard(onClick = { nav.push(Dest.Stats) }) {
                Row(Modifier.fillMaxWidth()) {
                    Metric("$pauses", "pausas", Modifier.weight(1f))
                    Metric("$notContinued", "no continuaste", Modifier.weight(1f))
                    Metric("$blocked", "intentos bloqueados", Modifier.weight(1f))
                }
                val top = (usage as? UsageResult.Done)?.usage?.entries?.sortedByDescending { it.value }?.take(3).orEmpty()
                if (top.isNotEmpty()) {
                    Spacer(Modifier.height(16.dp))
                    top.forEach { (pkg, ms) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(pkg, 32.dp); Spacer(Modifier.width(12.dp))
                            Text(appLabel(pkg), style = Type.bodyMedium, modifier = Modifier.weight(1f), maxLines = 1)
                            Text(Fmt.duration(ms), style = Type.body.copy(color = TT.TextSecondary))
                        }
                    }
                }
            }
        }
    }

    confirmEnd?.let { s ->
        ConfirmDialog(
            "¿Terminar «${s.name}»?",
            "Es la salida de emergencia: las apps quedarán disponibles salvo que otra sesión o rutina siga vigente. Quedará registrada en tu historial.",
            "Terminar sesión",
            onConfirm = {
                val t = System.currentTimeMillis()
                Store.update { st -> st.copy(sessions = st.sessions.map { if (it.id == s.id) it.copy(endedEarlyAtMs = t) else it }) }
                Store.log(EventType.SESSION_ENDED_EARLY, ref = s.id)
                confirmEnd = null; haptic(); nav.show("Sesión terminada")
            },
            onDismiss = { confirmEnd = null },
        )
    }
}

@Composable
private fun Metric(value: String, label: String, modifier: Modifier) {
    Column(modifier) {
        Text(value, style = Type.cardFigure)
        Text(label, style = Type.label, maxLines = 2)
    }
}

@Composable
fun ActiveCard(
    name: String, kind: String, packages: Set<String>, remainingMs: Long, operative: Boolean,
    action: String? = null, onAction: (() -> Unit)? = null, onClick: (() -> Unit)? = null,
) {
    TTCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(kind, style = Type.label)
                Text(name, style = Type.cardTitle, maxLines = 1)
            }
            StatusDot(operative, if (operative) "Protección activa" else "No operativa")
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(Fmt.countdown(remainingMs), style = Type.cardFigure.copy(fontFeatureSettings = "tnum"))
                Text("restante · ${appsSummary(packages.size)}", style = Type.secondary)
            }
            AppStack(packages)
        }
        if (action != null && onAction != null) {
            Spacer(Modifier.height(14.dp))
            SmallPill(action, onAction, Icons.Rounded.Close, tone = ButtonTone.Danger)
        }
    }
}

fun routineIcon(key: String) = when (key) {
    "morning" -> Icons.Rounded.WbSunny
    "study" -> Icons.Rounded.School
    "work" -> Icons.Rounded.Work
    "sleep" -> Icons.Rounded.Bedtime
    "focus" -> Icons.Rounded.CenterFocusStrong
    else -> Icons.Rounded.EventRepeat
}
