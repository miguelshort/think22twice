package app.thinktwice.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import app.thinktwice.R

/**
 * Sistema visual centralizado de thinktwice (adaptación oscura inspirada en el lenguaje de Revolut).
 * Los valores son especificaciones de thinktwice, no códigos oficiales de ninguna otra marca.
 */
object TT {
    // Paleta
    val Bg = Color(0xFF0B0C0F)
    val Surface = Color(0xFF15171C)
    val Card = Color(0xFF1E2128)
    val Control = Color(0xFF292D35)
    val Text = Color(0xFFF7F8FA)
    val TextSecondary = Color(0xFF9DA3AE)
    val Accent = Color(0xFF6C8CFF)
    val Positive = Color(0xFF65D6A0)
    val Danger = Color(0xFFF26B78)
    val Divider = Color(0x14FFFFFF)
    val Scrim = Color(0x99000000)
    /** Degradado muy sutil para la zona principal de Inicio. */
    val HeroTop = Color(0xFF151A2B)
}

object Dim {
    val screenH = 20.dp
    val section = 28.dp
    val cardPad = 18.dp
    val related = 10.dp
    val cardRadius = 22.dp
    val sheetRadius = 30.dp
    val buttonH = 54.dp
    val quickAction = 52.dp
    val touch = 48.dp
    val icon = 24.dp
    val rowIcon = 40.dp
}

object Motion {
    const val press = 120
    const val pressScale = 0.98f
    const val tab = 200
    const val detail = 250
    const val sheet = 290
    const val value = 400
}

val Inter = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

/** Interletreado -85 (≈ -0.085em) reservado a textos importantes, como pidió el usuario. */
private val Tight = (-0.085).em
/** Interletreado más suave para tamaños medianos en negrita, para no comprometer la lectura. */
private val Snug = (-0.03).em

object Type {
    val hero = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 52.sp, lineHeight = 56.sp, letterSpacing = Tight, color = TT.Text)
    val heroUnit = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 26.sp, letterSpacing = (-0.04).em, color = TT.Text)
    val screenTitle = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 36.sp, letterSpacing = Tight, color = TT.Text)
    val section = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 26.sp, letterSpacing = Snug, color = TT.Text)
    val cardTitle = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp, letterSpacing = (-0.01).em, color = TT.Text)
    val cardFigure = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 32.sp, letterSpacing = (-0.05).em, color = TT.Text)
    val body = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 22.sp, color = TT.Text)
    val bodyMedium = body.copy(fontWeight = FontWeight.Medium)
    val button = TextStyle(fontFamily = Inter, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, letterSpacing = (-0.01).em)
    val secondary = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 18.sp, color = TT.TextSecondary)
    val label = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp, color = TT.TextSecondary)
    val countdown = TextStyle(fontFamily = Inter, fontWeight = FontWeight.Bold, fontSize = 72.sp, lineHeight = 76.sp, letterSpacing = (-0.06).em, color = TT.Text,
        fontFeatureSettings = "tnum")
}
