package app.thinktwice

import app.thinktwice.core.*
import app.thinktwice.data.Codec
import org.junit.Assert.*
import org.junit.Test

class CodecTest {
    @Test fun roundTrip() {
        val s = AppState(
            settings = Settings(name = "Ana", waitSeconds = 20, allowedMinutes = 3, reduceMotion = true, onboardingDone = true),
            pausedApps = setOf("a.b"),
            sessions = listOf(BlockSession("s", "Foco", setOf("a.b"), 1000, 5000, 3000)),
            routines = listOf(Routine("r", "Noche", setOf("a.b"), 23 * 60, 7 * 60, setOf(1, 7), true)),
            challenges = listOf(Challenge("c", ChallengeKind.USAGE_GOAL, 7, 20000, goalMinutes = 30, manual = mapOf(20001L to true))),
            classes = mapOf("a.b" to AppClass.DISTRACTING),
            events = listOf(LogEvent(10, EventType.EXITED, "a.b")),
        )
        assertEquals(s, Codec.decode(Codec.encode(s)))
    }

    @Test(expected = IllegalArgumentException::class) fun rejectsForeignFile() { Codec.decode("{\"format\":\"otra\"}") }

    @Test(expected = Exception::class) fun rejectsBadRoutineHour() {
        val ok = Codec.encode(AppState(routines = listOf(Routine("r", "x", emptySet(), 0, 60, setOf(1), true))))
        Codec.decode(ok.replace("\"startMin\":0", "\"startMin\":5000"))
    }
}
