# Pruebas

## Realizadas (en el entorno de desarrollo, sin dispositivo)

| Área | Resultado |
|---|---|
| Motor de reglas: rutina que cruza la medianoche (lunes 23:00 → martes 07:00) | ✅ JUnit |
| Restricciones superpuestas y contiguas (no se libera al terminar la primera) | ✅ JUnit |
| Sesión que termina mientras una rutina sigue vigente | ✅ JUnit |
| Salida de emergencia de rutina solo hasta el final de la franja | ✅ JUnit |
| Pausa e intervalo permitido (expira exactamente al final) | ✅ JUnit |
| Bloqueo con prioridad sobre pausa con intervalo vigente | ✅ JUnit |
| Cambio de zona horaria (hora local de pared) | ✅ JUnit |
| Cambio a horario de verano (Madrid, 29-03-2026) | ✅ JUnit |
| Fórmula de productividad, exclusión de neutras/sin clasificar, denominador 0, semanal acumulada (no media) | ✅ JUnit |
| Próxima rutina | ✅ JUnit |
| Estados de reto: medido, manual, pendiente, sin datos | ✅ JUnit |
| Revisión sintáctica de todo el código Kotlin con el compilador | ✅ sin errores de sintaxis |

`CodecTest` (exportar/importar con validación) está incluido y se ejecuta con `./gradlew testDebugUnitTest`, pero no pudo ejecutarse aquí.

## Pendientes en un dispositivo real

El entorno donde se generó el proyecto no tenía Android SDK ni acceso a internet, así que **la app no se ha compilado con Gradle ni ejecutado**. La primera compilación en Android Studio puede señalar algún ajuste menor de API; si ocurre, el mensaje de error indica la línea exacta.

Lista de comprobación recomendada:

1. **Compilación**: `./gradlew assembleDebug` sin errores.
2. **Onboarding**: omitir introducción, nombre vacío, ninguna app; rechazar cada permiso y ver qué queda desactivado.
3. **Pausa**: abrir una app con pausa → cuenta atrás 15 s → «Continuar» deshabilitado hasta 0 → continuar → salir y volver antes de 5 min (sin pausa) → esperar 5 min dentro (vuelve la pausa) → «Salir» (registro «no continuaste»).
4. **Sin bucles**: abrir y cerrar rápido varias veces la misma app; girar la pantalla durante la cuenta atrás (no se reinicia).
5. **Bloqueo**: plantilla + 15 min; intentar abrir la app (pantalla con motivo y hora de fin); cerrar thinktwice desde Recientes y comprobar que sigue; terminar con salida de emergencia.
6. **Rutinas**: crear una que cruce la medianoche; dos superpuestas; suspender una activa; duplicar y eliminar.
7. **Reinicio del móvil** con una sesión activa: notificación restaurada y bloqueo vigente.
8. **Cambio de hora/zona** manual en Ajustes del sistema.
9. **Revocar permisos** (accesibilidad, uso, notificaciones) con la app abierta: Inicio y Diagnóstico deben mostrar «Protección no operativa» / «Sin permiso».
10. **Estadísticas**: comparar el total del día con Bienestar digital (pueden diferir algunos minutos por la forma de contar); días antiguos «sin datos».
11. **Sin conexión**: modo avión, todas las funciones operativas.
12. **Exportar/importar**: exportar, borrar datos, importar (confirmación), importar un archivo ajeno (error claro).
13. **Accesibilidad**: TalkBack en Inicio, calendario de retos y pantalla de pausa; tamaño de fuente máximo; pantalla de 5"; nombres de app largos.
14. **Batería**: dejar una noche con pausas activas y comprobar el consumo en Ajustes › Batería.
15. **Visual**: revisar cada pantalla, panel, formulario y estado (vacío, cargando, sin permiso, datos insuficientes, error, guardado, protección activa/no operativa) en el móvil.
