# Futura versión para iPhone

En iOS no existe un equivalente al servicio de accesibilidad de Android. La vía oficial es el framework **Screen Time API** (iOS 15+/16+):

- **Family Controls** — `AuthorizationCenter.shared.requestAuthorization(for: .individual)` para que la persona autorice el control de su propio dispositivo. Requiere el entitlement `com.apple.developer.family-controls`, que Apple concede bajo solicitud.
- **FamilyActivityPicker** — selección de apps/categorías. Devuelve *tokens* opacos: la app no conoce los nombres reales de las apps seleccionadas (privacidad por diseño).
- **Managed Settings** — `ManagedSettingsStore().shield.applications = tokens` aplica el bloqueo («escudo») del sistema. Es una restricción real del sistema, a diferencia de Android.
- **Device Activity** — `DeviceActivityCenter().startMonitoring(_:during:events:)` para rutinas (franjas con `DateComponents`) y umbrales de uso.
- **Extensiones necesarias**
  - `DeviceActivityMonitor` (extensión): aplica/retira escudos al empezar/terminar franjas o al alcanzar umbrales.
  - `ShieldConfiguration` (extensión): personaliza la pantalla de bloqueo (logo de thinktwice, mensaje).
  - `ShieldAction` (extensión): gestiona los botones del escudo (p. ej. «Salir»).
  - `DeviceActivityReport` (extensión): única forma de mostrar estadísticas de uso; se renderiza en un proceso aislado y los datos no pueden salir de él.
- **Pausa consciente con cuenta atrás**: no hay forma de interceptar la apertura con una cuenta atrás propia como en Android. Aproximación habitual: escudo + acción que abre thinktwice (o un Atajo/Automatización de la app Atajos) y, tras la espera, retira el escudo temporalmente con Device Activity.
- **Live Activities / Dynamic Island** (ActivityKit, iOS 16.1+): mostrar el tiempo restante de una sesión solo en dispositivos compatibles; en el resto, notificación local.
- Datos compartidos entre la app y las extensiones mediante App Group local; sin servidores.
