# thinktwice

App Android nativa (Kotlin + Jetpack Compose) para reducir el uso impulsivo del móvil con pausas conscientes, bloqueos temporales, rutinas, estadísticas y retos. Funciona sin cuentas, sin servidores, sin IA y sin conexión a internet (no declara el permiso `INTERNET`).

## Instalar en tu móvil

**Requisitos:** Android Studio (Ladybug 2024.2 o posterior), un móvil con Android 8.0 (API 26) o superior y un cable USB.

1. Descomprime el ZIP y, en Android Studio, elige **File › Open** y selecciona la carpeta `thinktwice`.
2. Espera a que termine la sincronización de Gradle (la primera vez descarga Gradle 8.14.3, AGP 8.7.3 y las librerías; necesita internet).
3. En el móvil: **Ajustes › Información del teléfono** › pulsa 7 veces en *Número de compilación* para activar las opciones de desarrollador. Después, en **Opciones de desarrollador**, activa **Depuración USB**.
4. Conecta el móvil, acepta la huella del ordenador y pulsa **Run ▶** (configuración `app`).

Desde terminal: `./gradlew installDebug` (o `gradlew.bat installDebug` en Windows). El APK queda en `app/build/outputs/apk/debug/app-debug.apk`; puedes copiarlo al móvil e instalarlo permitiendo «instalar apps desconocidas».

### Primer uso
El recorrido inicial te pide nombre (opcional), las apps que quieres controlar y explica cada permiso antes de abrir su ajuste:

| Función | Permiso | Dónde se concede |
|---|---|---|
| Pausas, bloqueos y rutinas | Servicio de accesibilidad de thinktwice | Ajustes › Accesibilidad › Apps instaladas › thinktwice |
| Estadísticas y retos de uso | Acceso a datos de uso | Ajustes › Apps › Acceso especial › Acceso a datos de uso |
| Cuenta atrás de sesiones y recordatorios | Notificaciones (Android 13+) | Diálogo del sistema |

En Android 13+ las apps instaladas fuera de Google Play tienen los **ajustes restringidos**: si el interruptor de accesibilidad aparece desactivado en gris, ve a **Ajustes › Apps › thinktwice › ⋮ › Permitir ajustes restringidos** y vuelve a intentarlo.

Recomendado: excluir thinktwice de la optimización de batería (Diagnóstico › Ejecución en segundo plano), sobre todo en Xiaomi, Huawei, Oppo/Realme, Vivo y Samsung.

## Estructura

```
app/src/main/java/app/thinktwice/
├── core/          Lógica pura (sin Android) — probada con JUnit
│   ├── Model.kt       Datos: ajustes, sesiones, rutinas, retos, eventos
│   ├── RuleEngine.kt  Decisión pausa/bloqueo, medianoche, solapes, zonas horarias
│   └── Metrics.kt     Productividad, evaluación de retos, formatos
├── data/          Persistencia local (JSON atómico) y exportación/importación validada
├── system/        Integración nativa
│   ├── GuardService.kt         Servicio de accesibilidad (solo nombre del paquete en primer plano)
│   ├── InterventionActivity.kt Pantalla de pausa / bloqueo
│   ├── UsageRepo.kt            UsageStatsManager.queryEvents
│   ├── Notifier.kt             Notificaciones, recordatorios y receptores (arranque, hora, zona)
│   ├── Perms.kt / Apps.kt      Diagnóstico de permisos, lista de apps, apps esenciales
└── ui/
    ├── theme/     Sistema visual centralizado: colores, tipografía, espaciado, radios, movimiento
    ├── components/ Botones píldora, acciones circulares, tarjetas, listas agrupadas, gráficos, paneles
    └── screens/   Onboarding, Inicio, Rutinas, Bloquear, Estadísticas, Retos, Perfil y Ajustes
```

Logo: `res/drawable-nodpi/logo_wordmark.png` es tu imagen recortada con fondo transparente (formas y proporciones intactas, sin redibujar). El icono de la app usa la misma imagen. Fuente: Inter (OFL, incluida localmente en `res/font`; licencia en `FONT_LICENSE_Inter.txt`).

## Pruebas

`./gradlew testDebugUnitTest` ejecuta las pruebas del motor de reglas (`app/src/test`). Ver `docs/PRUEBAS.md` para lo verificado y lo pendiente en un dispositivo real.

## Documentación
- `docs/ANDROID.md` — mecanismo de intervención, permisos, política de pausas y limitaciones.
- `docs/IOS.md` — notas para una futura versión de iPhone.
- `docs/PRUEBAS.md` — pruebas realizadas y pendientes.
