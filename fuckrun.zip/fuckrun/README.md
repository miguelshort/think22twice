# fuckrun

App Android nativa (Kotlin + Jetpack Compose) para registrar carreras privadas, entender tu progreso, organizar rutinas y coordinar salidas conjuntas. **No es una red social** y **no usa inteligencia artificial**.

## Compilar e instalar

Requisitos: Android Studio (Ladybug o posterior) con Android SDK 35 y JDK 17.

```bash
cp local.properties.example local.properties   # y rellena sdk.dir (y, opcionalmente, mapas y Firebase)
./gradlew assembleDebug                        # APK en app/build/outputs/apk/debug/
./gradlew installDebug                         # instala en un dispositivo conectado
./gradlew test                                 # tests de métricas y reglas
```

Sin claves, la app funciona entera para el registro personal, estadísticas y rutinas (sin cuenta y sin conexión). Los mapas usan OpenStreetMap estándar solo para desarrollo y la sección Club muestra «servicio no configurado». Ver `docs/SERVICIOS.md`.

## Estructura

```
app/src/main/java/app/fuckrun/
  domain/            Lógica pura y probada: métricas GPS, nivel, reglas de recomendación, progreso
  data/              Almacenamiento PERSONAL (Room + DataStore), municipios, catálogo de rutas, exportación
  data/shared/       Datos COMPARTIDOS (Firebase Auth + Firestore), separados del almacenamiento personal
  tracking/          Servicio en primer plano de ubicación (pantalla apagada, huecos, batería, recuperación)
  reminders/         Recordatorios de rutina y avisos de cambios en sesiones conjuntas
  ui/                Tema, componentes (barra flotante, hojas con desenfoque, difuminado superior), pantallas
firebase/firestore.rules   Reglas de seguridad del servicio compartido
tools/import_ine.py        Carga el listado completo de municipios del INE
docs/                      Decisiones, métricas, plantillas, rutas, servicios y exportación
```

## Decisiones importantes

- **Ubicación**: solo `ACCESS_FINE_LOCATION`/`COARSE` mientras se usa la app. El seguimiento con pantalla apagada se hace con un *foreground service* de tipo `location` que el usuario inicia, con notificación visible. **No** se pide ubicación en segundo plano permanente. Al terminar o descartar, la captura se detiene.
- **Resiliencia**: cada punto y evento se guarda al momento. Si el sistema cierra la app o se reinicia el dispositivo, al abrirla se ofrece continuar, terminar o descartar, indicando el tramo perdido. Los huecos nunca se dibujan como recorrido (línea discontinua) ni suman distancia.
- **Métricas**: filtros documentados en `docs/METRICAS.md`. Si no hay datos suficientes se muestra «–», nunca un valor inventado. Una parada real muestra 0.
- **Recomendaciones**: reglas explícitas y plantillas con procedencia (`docs/PLANTILLAS.md`). Cada propuesta indica qué respuestas usa. La carga nunca sube sola.
- **Rutas**: el catálogo se publica **vacío** a propósito. Solo se muestran recorridos verificados (`docs/RUTAS.md`). Sin catálogo, la app ofrece sesiones por tiempo o distancia.
- **Privacidad**: actividades privadas y locales. Nada de feed, seguidores, «me gusta», comentarios ni rankings. Apuntarse a una sesión no comparte ruta, ritmo, estadísticas ni posición.
- **Diseño**: estética oscura inspirada en Revolut con la paleta de este proyecto, Inter con interletreado −0,085 em en titulares, cifras tabulares, barra inferior flotante con desenfoque real (Haze → `RenderEffect` en Android 12+; superficie opaca en versiones anteriores), hojas inferiores con el mismo tratamiento y difuminado superior al desplazar.

## Pendiente antes de publicar

1. Compilar y probar en dispositivos reales (este proyecto se ha generado sin Android SDK; la lógica de dominio sí está compilada y probada).
2. Configurar proveedor de mapas con licencia comercial y proyecto Firebase propio.
3. Revisión profesional de las plantillas de entrenamiento.
4. Cargar el listado completo de municipios del INE y los primeros recorridos verificados.
5. Declaración del permiso de servicio en primer plano de ubicación en Google Play Console (vídeo y justificación).
