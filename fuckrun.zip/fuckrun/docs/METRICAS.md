# Métricas de sesión

Implementación: `domain/metrics/RunMetrics.kt`. Tests: `app/src/test/.../RunMetricsTest.kt` (14 casos).

## Definiciones
| Métrica | Definición |
|---|---|
| Tiempo transcurrido | Desde el inicio hasta el final. **Incluye** pausas. |
| Tiempo activo | Suma de intervalos grabando. **Excluye** pausas y tramos perdidos por cierre de la app o reinicio. |
| Distancia | Suma dentro de cada segmento registrado. Entre segmentos (pausa, pérdida de señal, cierre) no se suma nada. |
| Velocidad media activa | Distancia / tiempo activo. |
| Ritmo medio activo | Tiempo activo / distancia (min/km). |
| Velocidad actual | Desplazamiento en los últimos 10 s. En una parada real es **0**. Sin fijos recientes (>10 s): «–». |
| Velocidad máxima | Máximo de velocidades suavizadas (ventanas de 10 s con ≥3 puntos y ≥5 s). Nunca de un único salto. |
| Velocidad mínima en movimiento | Mínimo de esas ventanas por encima de 1,8 km/h (excluye paradas). |
| Parciales | Tiempo en movimiento registrado para cada km, interpolando el cruce. |

Los tiempos se miden con el reloj monotónico del sistema (`elapsedRealtime`), así que **cambiar la hora no altera duraciones**. Tras un reinicio se usa el reloj de pared y se marca el hueco.

## Filtros
1. Se descartan fijos con precisión peor que **25 m**.
2. Se descartan fijos que implican más de **45 km/h** respecto al último aceptado (saltos de GPS).
3. Posiciones suavizadas con una media centrada de **5 fijos** (ventana simétrica en los extremos).
4. Umbral anti-ruido **acumulado** desde un punto ancla: solo se suma cuando el desplazamiento supera `max(4 m, precisión declarada)`. Evita distancia fantasma estando parado sin perder distancia en trotes lentos.
5. Las velocidades de ventana usan los instantes de los puntos ancla para evitar sesgos.
6. Sin señal durante **15 s**: se registra el hueco y, al volver, se abre un segmento nuevo.

## Agregados (Progreso)
El ritmo de un periodo es **tiempo acumulado / distancia acumulada** de las actividades con distancia, no la media de ritmos. Las actividades manuales se cuentan aparte y no tienen ruta ni máximos o mínimos.
