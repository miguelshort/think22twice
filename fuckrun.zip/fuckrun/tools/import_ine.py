#!/usr/bin/env python3
"""Convierte la "Relación de municipios y sus códigos por provincias" del INE (CSV/XLSX
exportado a CSV con columnas CPRO, CMUN, NOMBRE) al formato app/src/main/assets/municipios.csv.
Fuente: https://www.ine.es/daco/daco42/codmun/codmun.htm  (datos abiertos del INE; cita la fuente).
Uso: python3 tools/import_ine.py diccionarioXX.csv > app/src/main/assets/municipios.csv
"""
import csv, sys
PROV = {}
with open("app/src/main/assets/municipios.csv", encoding="utf-8") as f:
    for row in csv.reader(l for l in f if not l.startswith("#")):
        if row[0] != "cpro": PROV[row[0]] = row[1]
print("# Fuente: INE, Relación de municipios y sus códigos por provincias")
print("cpro,provincia,municipio")
with open(sys.argv[1], encoding=sys.argv[2] if len(sys.argv) > 2 else "utf-8") as f:
    delim = ";" if ";" in f.readline() else ","
    f.seek(0)
    for r in csv.DictReader(f, delimiter=delim):
        cpro = str(r["CPRO"]).zfill(2)
        sys.stdout.write(f'{cpro},"{PROV.get(cpro, cpro)}","{r["NOMBRE"].strip()}"\n')
