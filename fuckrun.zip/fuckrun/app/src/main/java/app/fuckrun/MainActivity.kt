package app.fuckrun

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.navArgument
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import app.fuckrun.data.AppSettings
import app.fuckrun.data.db.RunStatus
import app.fuckrun.domain.Fmt
import app.fuckrun.reminders.Reminders
import app.fuckrun.tracking.Tracking
import app.fuckrun.ui.components.*
import app.fuckrun.ui.screens.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.FuckrunTheme
import app.fuckrun.ui.theme.T
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val pendingIntent = MutableStateFlow<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        pendingIntent.value = intent
        Reminders.rescheduleAll(applicationContext)
        setContent { FuckrunTheme { FuckrunRoot(pendingIntent) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pendingIntent.value = intent
    }
}

object Routes {
    const val HOME = "home"; const val ROUTES = "routes"; const val CLUB = "club"; const val ROUTINES = "routines"; const val PROGRESS = "progress"
    const val PROFILE = "profile"; const val ONBOARDING = "onboarding"; const val ACTIVE = "active"; const val MANUAL = "manual"
    const val CLUB_CREATE = "club/create"; const val ROUTINE_NEW = "routine/new"
    fun prerun(kind: String = "FREE", planned: Long? = null, route: String? = null, shared: String? = null, sharedName: String? = null) =
        "prerun?kind=$kind&planned=${planned ?: -1}&route=${route ?: ""}&shared=${shared ?: ""}&sharedName=${android.net.Uri.encode(sharedName ?: "")}"
    fun summary(id: Long) = "summary/$id"
    fun activity(id: Long) = "activity/$id"
    fun clubSession(id: String) = "club/session/$id"
    fun clubEdit(id: String) = "club/edit/$id"
    fun clubJoin(code: String = "") = "club/join?code=$code"
}

val topLevel = listOf(
    NavItem(Routes.HOME, "Inicio", Icons.Rounded.Home),
    NavItem(Routes.ROUTES, "Rutas", Icons.Rounded.Map),
    NavItem(Routes.CLUB, "Club", Icons.Rounded.Groups),
    NavItem(Routes.ROUTINES, "Rutinas", Icons.Rounded.CalendarMonth),
    NavItem(Routes.PROGRESS, "Progreso", Icons.Rounded.Insights),
)

@Composable
fun FuckrunRoot(intents: MutableStateFlow<Intent?>) {
    val ctx = LocalContext.current
    val graph = FuckrunApp.graph
    val haze = remember { HazeState() }
    val sheet = remember { SheetController() }
    val nav = rememberNavController()
    val settings by produceState<AppSettings?>(null) { graph.profile.settings.collect { value = it } }
    val live by Tracking.live.collectAsStateWithLifecycle()
    val ended by Tracking.ended.collectAsStateWithLifecycle()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val scope = rememberCoroutineScope()
    var navHeight by remember { mutableStateOf(0.dp) }
    val density = LocalDensity.current
    val bottomInset = with(density) { WindowInsets.navigationBars.getBottom(this).toDp() }

    val s = settings ?: run { Box(Modifier.fillMaxSize().background(C.Bg)); return }
    val startOnboarding = remember { !s.onboardingDone }

    // Sesión terminada -> pantalla de guardar/descartar
    LaunchedEffect(ended) { ended?.let { nav.navigate(Routes.summary(it)) { popUpTo(Routes.HOME) }; Tracking.consumeEnded() } }

    // Invitaciones y notificación de sesión activa
    val pending by intents.collectAsStateWithLifecycle()
    LaunchedEffect(pending) {
        val i = pending ?: return@LaunchedEffect
        intents.value = null
        val data = i.data
        if (data?.scheme == "fuckrun" && data.host == "join") nav.navigate(Routes.clubJoin(data.lastPathSegment ?: ""))
        if (i.getBooleanExtra("openActiveRun", false) && Tracking.live.value != null) nav.navigate(Routes.ACTIVE) { launchSingleTop = true }
    }

    LaunchedEffect(Unit) { app.fuckrun.reminders.watchClubChanges(ctx.applicationContext) }

    // Recuperación de una sesión que no terminó correctamente (proceso cerrado, reinicio…)
    LaunchedEffect(Unit) {
        if (Tracking.live.value != null) return@LaunchedEffect
        val r = graph.runs.unfinished() ?: return@LaunchedEffect
        if (r.status == RunStatus.ENDED_UNSAVED) { nav.navigate(Routes.summary(r.id)); return@LaunchedEffect }
        val last = graph.runs.points(r.id).lastOrNull()?.wallMs ?: r.startedAtWall
        val lostMin = ((System.currentTimeMillis() - last) / 60000).coerceAtLeast(0)
        sheet.show {
            Text("Hay una sesión sin terminar", style = T.Section)
            Spacer(Modifier.height(8.dp))
            Text("El registro se interrumpió (la app se cerró o el dispositivo se reinició). Último dato guardado hace $lostMin min. " +
                "Ese tramo no se ha registrado y se mostrará como información incompleta.", style = T.Body.copy(color = C.TextSec))
            Spacer(Modifier.height(18.dp))
            if (Tracking.hasLocationPermission(ctx)) {
                PillButton("Continuar registrando", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) {
                    sheet.hide(); scope.launch { graph.runs.markInterrupted(r.id); Tracking.continueRun(ctx, r.id); nav.navigate(Routes.ACTIVE) }
                }
                Spacer(Modifier.height(10.dp))
            }
            PillButton("Terminar y revisar", color = C.Blue, icon = Icons.Rounded.Flag, modifier = Modifier.fillMaxWidth()) {
                sheet.hide(); scope.launch { graph.runs.markInterrupted(r.id); graph.runs.endRecording(r.id); nav.navigate(Routes.summary(r.id)) }
            }
            Spacer(Modifier.height(10.dp))
            PillButton("Descartar", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) {
                sheet.confirm("¿Descartar la sesión?", "Se borrarán los datos registrados de esta sesión.", "Descartar", C.Red) {
                    scope.launch { graph.runs.discard(r.id) }
                }
            }
        }
    }

    val showNav = route in topLevel.map { it.route }
    CompositionLocalProvider(LocalHaze provides haze, LocalSheet provides sheet,
        LocalNavPadding provides if (showNav) navHeight + bottomInset + 12.dp else 0.dp) {
        Box(Modifier.fillMaxSize().background(C.Bg)) {
            Box(Modifier.fillMaxSize().hazeSource(haze)) {
                AppNavHost(nav, startOnboarding = startOnboarding)
            }
            if (showNav) Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp)) {
                live?.let { l ->
                    Row(Modifier.padding(horizontal = 28.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(50))
                        .background(if (l.status == RunStatus.PAUSED) C.Red else C.Green).clickable { nav.navigate(Routes.ACTIVE) }
                        .padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (l.status == RunStatus.PAUSED) Icons.Rounded.Pause else Icons.Rounded.DirectionsRun, null, tint = C.OnColor)
                        Spacer(Modifier.width(8.dp))
                        Text("${if (l.status == RunStatus.PAUSED) "En pausa" else "Grabando"} · ${Fmt.km(l.stats?.distanceM)} km · ${Fmt.duration(l.stats?.activeMs)}",
                            style = T.BodyStrong.copy(color = C.OnColor), modifier = Modifier.weight(1f))
                        Text("Volver", style = T.BodyStrong.copy(color = C.OnColor))
                    }
                }
                FloatingNavBar(topLevel, route, onSelect = { r ->
                    nav.navigate(r) { popUpTo(Routes.HOME) { saveState = true }; launchSingleTop = true; restoreState = true }
                }, modifier = rememberNavHeight { navHeight = it })
            }
            SheetHost(sheet)
        }
    }
}

private fun optionalArg(name: String) = navArgument(name) { type = NavType.StringType; nullable = true; defaultValue = null }

@Composable
private fun AppNavHost(nav: NavHostController, startOnboarding: Boolean) {
    NavHost(nav, startDestination = if (startOnboarding) Routes.ONBOARDING else Routes.HOME) {
        composable(Routes.HOME) { HomeScreen(nav) }
        composable(Routes.ROUTES) { RoutesScreen(nav) }
        composable(Routes.CLUB) { ClubScreen(nav) }
        composable(Routes.ROUTINES) { RoutinesScreen(nav) }
        composable(Routes.PROGRESS) { ProgressScreen(nav) }
        composable(Routes.PROFILE) { ProfileScreen(nav) }
        composable(Routes.ONBOARDING) { OnboardingScreen(nav) }
        composable("prerun?kind={kind}&planned={planned}&route={route}&shared={shared}&sharedName={sharedName}",
            arguments = listOf("kind", "planned", "route", "shared", "sharedName").map { optionalArg(it) }) { e ->
            val a = e.arguments
            PreRunScreen(nav, a?.getString("kind") ?: "FREE", a?.getString("planned")?.toLongOrNull()?.takeIf { it > 0 },
                a?.getString("route")?.ifBlank { null }, a?.getString("shared")?.ifBlank { null }, a?.getString("sharedName")?.ifBlank { null })
        }
        composable(Routes.ACTIVE) { ActiveRunScreen(nav) }
        composable("summary/{id}") { e -> ActivityScreen(nav, e.arguments?.getString("id")!!.toLong(), summaryMode = true) }
        composable("activity/{id}") { e -> ActivityScreen(nav, e.arguments?.getString("id")!!.toLong(), summaryMode = false) }
        composable(Routes.MANUAL) { ManualActivityScreen(nav) }
        composable(Routes.CLUB_CREATE) { ClubEditScreen(nav, null) }
        composable("club/edit/{id}") { e -> ClubEditScreen(nav, e.arguments?.getString("id")) }
        composable("club/session/{id}") { e -> ClubSessionScreen(nav, e.arguments?.getString("id")!!) }
        composable("club/join?code={code}", arguments = listOf(optionalArg("code"))) { e -> ClubJoinScreen(nav, e.arguments?.getString("code") ?: "") }
        composable(Routes.ROUTINE_NEW) { RoutineNewScreen(nav) }
    }
}
