package app.fuckrun.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.roundToInt

val ES: Locale = Locale("es", "ES")
const val NO_DATA = "–"

object Fmt {
    fun duration(ms: Long?): String {
        if (ms == null) return NO_DATA
        val s = ms / 1000
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
    }
    fun durationShort(ms: Long): String {
        val totalMin = ms / 60000
        val h = totalMin / 60; val m = totalMin % 60
        return if (h > 0) "${h} h ${m} min" else "${m} min"
    }
    fun km(meters: Double?, decimals: Int = 2): String =
        if (meters == null) NO_DATA else "%.${decimals}f".format(ES, meters / 1000.0)
    fun kmh(mps: Double?): String = if (mps == null) NO_DATA else "%.1f".format(ES, mps * 3.6)
    fun pace(secPerKm: Double?): String {
        if (secPerKm == null || secPerKm.isNaN() || secPerKm.isInfinite() || secPerKm > 3600) return NO_DATA
        val t = secPerKm.roundToInt()
        return "%d:%02d".format(t / 60, t % 60)
    }
    fun dayName(d: DayOfWeek) = d.getDisplayName(TextStyle.FULL, ES).replaceFirstChar { it.uppercase() }
    fun dayShort(d: DayOfWeek) = d.getDisplayName(TextStyle.SHORT, ES).replaceFirstChar { it.uppercase() }.trimEnd('.')
    fun date(d: LocalDate) = "${d.dayOfMonth} ${d.month.getDisplayName(TextStyle.SHORT, ES).trimEnd('.')} ${d.year}"
    fun dateLong(d: LocalDate) = "${dayName(d.dayOfWeek)}, ${d.dayOfMonth} de ${d.month.getDisplayName(TextStyle.FULL, ES)}"
    fun month(m: java.time.YearMonth) =
        m.month.getDisplayName(TextStyle.FULL, ES).replaceFirstChar { it.uppercase() } + " " + m.year
}
