package app.fuckrun.data

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import app.fuckrun.data.db.PointEntity
import app.fuckrun.data.db.RunEntity
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import java.io.File
import java.time.Instant

/**
 * Exportación de datos propios.
 *  - GPX 1.1 por actividad: un <trkseg> por segmento registrado (los huecos no se rellenan).
 *  - JSON "fuckrun-export v1" con todas las actividades, rutinas y ajustes (esquema en docs/EXPORTACION.md).
 */
object Exporter {

    fun gpx(run: RunEntity, points: List<PointEntity>): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8"?>""").append('\n')
        append("""<gpx version="1.1" creator="fuckrun" xmlns="http://www.topografix.com/GPX/1/1">""").append('\n')
        append("<metadata><time>${Instant.ofEpochMilli(run.startedAtWall)}</time></metadata>\n")
        append("<trk><name>fuckrun ${Instant.ofEpochMilli(run.startedAtWall)}</name><type>running</type>\n")
        points.groupBy { it.segment }.toSortedMap().values.forEach { seg ->
            append("<trkseg>\n")
            seg.forEach { p ->
                append("""<trkpt lat="${p.lat}" lon="${p.lon}">""")
                p.altitudeM?.let { append("<ele>%.1f</ele>".format(java.util.Locale.US, it)) }
                append("<time>${Instant.ofEpochMilli(p.wallMs)}</time></trkpt>\n")
            }
            append("</trkseg>\n")
        }
        append("</trk>\n</gpx>\n")
    }

    @Serializable data class ExportPoint(val segment: Int, val time: Long, val lat: Double, val lon: Double, val accuracyM: Float, val altitudeM: Double?)
    @Serializable data class ExportRun(
        val id: Long, val startedAt: Long, val endedAt: Long?, val source: String, val kind: String,
        val distanceM: Double?, val elapsedMs: Long, val activeMs: Long, val avgSpeedMps: Double?, val maxSpeedMps: Double?,
        val minMovingSpeedMps: Double?, val lostMs: Long, val note: String, val plannedSessionId: Long?, val points: List<ExportPoint>,
    )
    @Serializable data class ExportPlanned(val id: Long, val routineId: Long, val name: String, val epochDay: Long, val type: String,
        val targetMinutes: Int?, val targetKm: Double?, val linkedRunId: Long?)
    @Serializable data class ExportAll(val format: String = "fuckrun-export", val version: Int = 1, val exportedAt: Long,
        val settings: AppSettings? = null, val runs: List<ExportRun>, val planned: List<ExportPlanned>)

    fun exportRun(r: RunEntity, pts: List<PointEntity>) = ExportRun(r.id, r.startedAtWall, r.endedAtWall, r.source, r.kind, r.distanceM,
        r.elapsedMs, r.activeMs, r.avgSpeedMps, r.maxSpeedMps, r.minMovingSpeedMps, r.lostMs, r.note, r.plannedSessionId,
        pts.map { ExportPoint(it.segment, it.wallMs, it.lat, it.lon, it.accuracyM, it.altitudeM) })

    fun json(all: ExportAll): String = AppJson.encodeToString(all)

    /** Escribe en caché y abre la hoja de compartir del sistema. El aviso de privacidad se muestra ANTES en la UI. */
    fun share(ctx: Context, fileName: String, mime: String, content: String) {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, fileName).apply { writeText(content) }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val send = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Exportar").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
