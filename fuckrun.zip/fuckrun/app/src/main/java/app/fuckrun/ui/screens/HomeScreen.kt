package app.fuckrun.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.AppSettings
import app.fuckrun.data.PlanState
import app.fuckrun.data.db.RunKind
import app.fuckrun.data.shared.SessionStatus
import app.fuckrun.data.state
import app.fuckrun.domain.*
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.LocalTime

@Composable
fun HomeScreen(nav: NavController) {
    val g = FuckrunApp.graph
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    val runs by remember { g.runs.finishedRuns() }.collectAsStateWithLifecycle(emptyList())
    val planned by remember { g.routines.planned() }.collectAsStateWithLifecycle(emptyList())
    val shared by remember { g.shared.mySessions() }.collectAsStateWithLifecycle(emptyList())
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()

    val week = PeriodRange.current(Period.WEEK)
    val totals = ProgressCalc.totals(ProgressCalc.inRange(runs, week))
    val today = LocalDate.now()
    val next = planned.filter { it.state() == PlanState.PENDING }.minByOrNull { it.epochDay }
    val nextMeet = shared.filter { it.status == SessionStatus.SCHEDULED && it.startAt > System.currentTimeMillis() }.minByOrNull { it.startAt }
    val proposal = remember(settings.answers) { RecommendationEngine.proposal(settings.answers) }
    val hour = LocalTime.now().hour

    ScreenScaffold(title = null, header = {
        Logo(height = 30.dp)
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(44.dp).clip(CircleShape).background(C.Control).clickable { nav.navigate(Routes.PROFILE) }, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Person, "Perfil y ajustes", tint = C.Text)
        }
    }) {
        item {
            Text(when (hour) { in 6..13 -> "Buenos días"; in 14..20 -> "Buenas tardes"; else -> "Buenas noches" }, style = T.ScreenTitle,
                modifier = Modifier.padding(start = 4.dp, top = 8.dp))
        }
        item {
            FCard {
                Text("Esta semana", style = T.Label)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(Fmt.km(totals.distanceM, 1), style = T.HomeFigure)
                    Text(" km", style = T.Section.copy(color = C.TextSec), modifier = Modifier.padding(bottom = 6.dp))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Stat("Tiempo activo", Fmt.durationShort(totals.activeMs))
                    Stat("Sesiones", "${totals.sessions}")
                    Stat("Ritmo medio", Fmt.pace(totals.aggregatedPaceSecPerKm), "min/km")
                }
            }
        }
        item {
            PillButton("Empezar a correr", color = C.Green, icon = Icons.Rounded.PlayArrow, big = true, modifier = Modifier.fillMaxWidth()) {
                nav.navigate(Routes.prerun())
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                CircleAction(Icons.Rounded.Repeat, "Rutina") { nav.navigate(Routes.ROUTINES) }
                CircleAction(Icons.Rounded.Insights, "Progreso") { nav.navigate(Routes.PROGRESS) }
                CircleAction(Icons.Rounded.Groups, "Encuentros") { nav.navigate(Routes.CLUB) }
                CircleAction(Icons.Rounded.EditNote, "Añadir manual") { nav.navigate(Routes.MANUAL) }
            }
        }
        item { SectionTitle("Próxima sesión") }
        item {
            if (next != null) FCard(onClick = { nav.navigate(Routes.prerun(RunKind.ROUTINE, planned = next.id)) }) {
                val d = LocalDate.ofEpochDay(next.epochDay)
                Text(if (d == today) "Hoy" else Fmt.dateLong(d), style = T.Label)
                Text(next.name, style = T.Section)
                Text(listOfNotNull(next.targetMinutes?.let { "$it min" }, next.targetKm?.let { "${Fmt.km(it * 1000, 1)} km" }, next.structure.ifBlank { null }).joinToString(" · "), style = T.Body.copy(color = C.TextSec))
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Empezar", color = C.Green, icon = Icons.Rounded.PlayArrow) { nav.navigate(Routes.prerun(RunKind.ROUTINE, planned = next.id)) }
                    PillButton("Continuar rutina", color = C.Control, textColor = C.Text) { nav.navigate(Routes.ROUTINES) }
                }
            } else FCard(onClick = { nav.navigate(Routes.ROUTINES) }) {
                Text("Sin sesiones planificadas", style = T.BodyStrong)
                Text("Crea una rutina desde una plantilla o a mano.", style = T.Label)
            }
        }
        if (nextMeet != null) {
            item { SectionTitle("Siguiente encuentro") }
            item {
                FCard(onClick = { nav.navigate(Routes.clubSession(nextMeet.id)) }) {
                    val dt = Instant.ofEpochMilli(nextMeet.startAt).atZone(ZoneId.systemDefault())
                    Text("${Fmt.dateLong(dt.toLocalDate())} · ${"%02d:%02d".format(dt.hour, dt.minute)}", style = T.Label)
                    Text(nextMeet.name, style = T.Section)
                    Text(nextMeet.meetingLabel, style = T.Body.copy(color = C.TextSec))
                }
            }
        }
        item { SectionTitle("Para hoy") }
        item {
            ProposalCard(proposal, onStart = { nav.navigate(Routes.prerun()) }, onSave = { p ->
                sheet.pick("¿Qué día?", (0..6).map { today.plusDays(it.toLong()) }, { if (it == today) "Hoy" else Fmt.dateLong(it) }, null) { d ->
                    scope.launch { planProposal(p, d) }
                }
            })
        }
        if (totals.sessions > 0) item {
            FCard(onClick = { nav.navigate(Routes.PROGRESS) }) {
                Text("Días activos esta semana", style = T.Label)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    (0..6).forEach { i ->
                        val d = week.start.plusDays(i.toLong())
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(30.dp).clip(CircleShape).background(if (d in totals.activeDays) C.Blue else C.Control))
                            Text(Fmt.dayShort(d.dayOfWeek).take(1), style = T.Label)
                        }
                    }
                }
            }
        }
    }
}
