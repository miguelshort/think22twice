package app.fuckrun.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.AppSettings
import app.fuckrun.data.Exporter
import app.fuckrun.data.PrimaryMetric
import app.fuckrun.data.shared.SharedState
import app.fuckrun.domain.LevelClassifier
import app.fuckrun.domain.Templates
import app.fuckrun.reminders.Reminders
import app.fuckrun.tracking.Tracking
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(nav: NavController) {
    val ctx = LocalContext.current
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    val s by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    val shared by g.shared.state.collectAsStateWithLifecycle(SharedState.NotConfigured)
    val level = LevelClassifier.classify(s.answers)
    fun appSettings() = ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)))

    ScreenScaffold("Perfil y ajustes") {
        item { SectionTitle("Tu punto de partida") }
        item {
            FCard {
                Text("Nivel orientativo", style = T.Label)
                Text(level.level.label, style = T.Section)
                Text(level.reasons.joinToString(" "), style = T.Label)
                Spacer(Modifier.height(10.dp))
                PillButton("Editar respuestas del formulario", color = C.Control, textColor = C.Text, icon = Icons.Rounded.Edit) { nav.navigate(Routes.ONBOARDING) }
            }
        }
        item {
            FCard {
                ListRow("Ciudad", listOfNotNull(s.answers.municipality, s.answers.province).joinToString(", ").ifBlank { "Sin elegir" }, leading = Icons.Rounded.Place) {
                    sheet.show {
                        Text("Municipio", style = T.Section); Spacer(Modifier.height(10.dp))
                        MunicipalityPicker(null) { m -> scope.launch { g.profile.update { it.copy(answers = it.answers.copy(municipality = m?.name, province = m?.province)) } }; sheet.hide() }
                    }
                }
                ListRow("Preferencias", listOf(s.answers.social.label, s.answers.environments.joinToString { it.label }.ifBlank { null }, s.answers.routeShape.label)
                    .filterNotNull().joinToString(" · "), leading = Icons.Rounded.Tune) { nav.navigate(Routes.ONBOARDING) }
            }
        }
        item { SectionTitle("Registro") }
        item {
            FCard {
                ListRow("Unidades", "Kilómetros, metros, km/h y min/km", leading = Icons.Rounded.Straighten, trailing = null)
                ListRow("Métrica principal durante la carrera", s.primaryMetric.label, leading = Icons.Rounded.Speed) {
                    sheet.pick("Métrica principal", PrimaryMetric.entries, { it.label }, s.primaryMetric) { m -> scope.launch { g.profile.update { it.copy(primaryMetric = m) } } }
                }
                ToggleRow("Cuenta atrás antes de empezar", s.countdown) { v -> scope.launch { g.profile.update { it.copy(countdown = v) } } }
            }
        }
        item { SectionTitle("Permisos y avisos") }
        item {
            FCard {
                ListRow("Ubicación", if (Tracking.hasLocationPermission(ctx)) "Concedida (solo mientras usas la app)" else "No concedida", leading = Icons.Rounded.LocationOn) { appSettings() }
                ListRow("Notificaciones", if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) "Activadas" else "Desactivadas", leading = Icons.Rounded.Notifications) { appSettings() }
                ToggleRow("Recordatorios de rutina", s.remindersEnabled) { v -> scope.launch { g.profile.update { it.copy(remindersEnabled = v) }; Reminders.rescheduleAll(ctx) } }
            }
        }
        item { SectionTitle("Privacidad") }
        item {
            FCard {
                Text("Tus actividades son privadas y se guardan en este dispositivo. No hay feed, seguidores, “me gusta”, comentarios ni clasificaciones. " +
                    "Apuntarte a una sesión conjunta no comparte tu ruta, ritmo, estadísticas ni posición en directo. La ubicación solo se usa durante una carrera que tú inicias.",
                    style = T.Body.copy(color = C.TextSec))
            }
        }
        item {
            FCard {
                ListRow("Exportar todos mis datos (JSON)", "Formato documentado en docs/EXPORTACION.md", leading = Icons.Rounded.Download) {
                    privacyWarning(sheet) {
                        scope.launch {
                            val runs = g.runs.finishedRuns().first()
                            val all = Exporter.ExportAll(exportedAt = System.currentTimeMillis(), settings = g.profile.settings.first(),
                                runs = runs.map { Exporter.exportRun(it, g.runs.points(it.id)) },
                                planned = g.routines.plannedOnce().map { Exporter.ExportPlanned(it.id, it.routineId, it.name, it.epochDay, it.type, it.targetMinutes, it.targetKm, it.linkedRunId) })
                            Exporter.share(ctx, "fuckrun-datos.json", "application/json", Exporter.json(all))
                        }
                    }
                }
                ListRow("Eliminar todos mis datos", "Actividades, rutinas, favoritos y respuestas de este dispositivo", leading = Icons.Rounded.DeleteForever, leadingTint = C.Red) {
                    sheet.confirm("¿Eliminar todos tus datos?", "Se borrará todo lo guardado en este dispositivo. No se puede deshacer.", "Eliminar todo", C.Red) {
                        scope.launch {
                            if (Tracking.live.value != null) Tracking.stop(ctx)
                            g.runs.deleteAll(); g.routines.deleteAll(); g.db.favorites().deleteAll(); g.profile.clear()
                            Reminders.rescheduleAll(ctx)
                            nav.navigate(Routes.ONBOARDING) { popUpTo(0) }
                        }
                    }
                }
            }
        }
        item { SectionTitle("Cuenta para sesiones conjuntas") }
        item {
            FCard {
                when (shared) {
                    SharedState.NotConfigured -> Text("Servicio compartido no configurado en esta versión. No hace falta cuenta para nada más.", style = T.Label)
                    SharedState.SignedOut -> Text("Sin perfil compartido. Solo se necesita para crear o aceptar sesiones conjuntas (en Club).", style = T.Label)
                    is SharedState.Ready -> {
                        ListRow("Nombre visible", s.sharedDisplayName.ifBlank { "Sin nombre" }, leading = Icons.Rounded.Badge, trailing = null)
                        ListRow("Cerrar sesión", leading = Icons.Rounded.Logout) { g.shared.signOut() }
                        ListRow("Eliminar cuenta compartida", "Cancela tus confirmaciones y las sesiones que organizas", leading = Icons.Rounded.PersonRemove, leadingTint = C.Red) {
                            sheet.confirm("¿Eliminar la cuenta compartida?", "Se cancelarán tus asistencias y las sesiones que organizas. Tus datos personales del dispositivo no se tocan.", "Eliminar", C.Red) {
                                scope.launch { runCatching { g.shared.deleteAccount() }.onFailure { e -> sheet.show { Text(e.message ?: "Error", style = T.Body) } } }
                            }
                        }
                    }
                }
            }
        }
        item { SectionTitle("Acerca de") }
        item {
            FCard {
                Text("Mapas: ${app.fuckrun.BuildConfig.MAP_ATTRIBUTION}. Tipografía Inter (SIL Open Font License).", style = T.Label)
                Spacer(Modifier.height(6.dp))
                Text("Plantillas de entrenamiento: " + Templates.all.joinToString(" ") { "${it.name}: ${it.source}" }, style = T.Label)
                Spacer(Modifier.height(6.dp))
                Text("fuckrun no usa inteligencia artificial: las propuestas salen de reglas explícitas y revisables.", style = T.Label)
            }
        }
        item { PillButton("Volver", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { nav.popBackStack() } }
    }
}

@Composable
private fun ToggleRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = T.BodyStrong, modifier = Modifier.weight(1f))
        Switch(value, onChange, colors = SwitchDefaults.colors(checkedTrackColor = C.Green, checkedThumbColor = C.OnColor))
    }
}
