package app.fuckrun.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import app.fuckrun.domain.Fmt
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T

/** Gráficas de progreso: siempre azul #6C8CFF, con intensidades distintas por periodo y leyenda. */
@Composable
fun BarChart(current: List<Pair<String, Double>>, previous: List<Double>?, unit: String, modifier: Modifier = Modifier) {
    val maxV = (current.map { it.second } + (previous ?: emptyList())).maxOrNull()?.takeIf { it > 0 } ?: 1.0
    Column(modifier.semantics { contentDescription = "Gráfico de barras de $unit por periodo" }) {
        Text("máx. ${"%.1f".format(maxV)} $unit", style = T.Label)
        Spacer(Modifier.height(8.dp))
        Canvas(Modifier.fillMaxWidth().height(150.dp)) {
            val n = current.size
            val slot = size.width / n
            val barW = (slot * if (previous != null) 0.32f else 0.5f).coerceAtMost(28.dp.toPx())
            val r = CornerRadius(6.dp.toPx())
            current.forEachIndexed { i, (_, v) ->
                val cx = slot * i + slot / 2
                previous?.getOrNull(i)?.let { pv ->
                    val h = (pv / maxV * size.height).toFloat()
                    drawRoundRect(C.Blue.copy(alpha = 0.32f), Offset(cx - barW - 2.dp.toPx(), size.height - h), Size(barW, h), r)
                }
                val h = (v / maxV * size.height).toFloat()
                val x = if (previous != null) cx + 2.dp.toPx() else cx - barW / 2
                if (h > 0) drawRoundRect(C.Blue, Offset(x, size.height - h), Size(barW, h), r)
                else drawRoundRect(C.Control, Offset(x, size.height - 3.dp.toPx()), Size(barW, 3.dp.toPx()), r)
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
            current.forEach { Text(it.first, style = T.Label, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
        }
        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            LegendDot(C.Blue); Text(" Periodo actual", style = T.Label)
            if (previous != null) { Spacer(Modifier.width(14.dp)); LegendDot(C.Blue.copy(alpha = 0.32f)); Text(" Periodo anterior", style = T.Label) }
        }
    }
}

@Composable
fun LegendDot(color: Color) = Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(color))

/** Evolución del ritmo medio agregado (min/km). Los cubos sin datos quedan vacíos, sin interpolar. */
@Composable
fun PaceLine(series: List<Double?>, labels: List<String>, modifier: Modifier = Modifier) {
    val vals = series.filterNotNull()
    if (vals.size < 2) { Text("Sin datos suficientes para mostrar la evolución.", style = T.Label, modifier = modifier); return }
    val lo = vals.min(); val hi = vals.max(); val span = (hi - lo).takeIf { it > 1 } ?: 60.0
    Column(modifier) {
        Text("${Fmt.pace(lo)} – ${Fmt.pace(hi)} min/km", style = T.Label)
        Canvas(Modifier.fillMaxWidth().height(110.dp).padding(vertical = 8.dp)) {
            val step = size.width / (series.size - 1).coerceAtLeast(1)
            // Ritmo más bajo (más rápido) arriba. Solo se unen cubos consecutivos con datos.
            fun y(v: Double) = ((v - lo) / span * size.height).toFloat()
            var path: Path? = null
            series.forEachIndexed { i, v ->
                if (v == null) { path?.let { drawPath(it, C.Blue, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)) }; path = null }
                else {
                    val p = Offset(step * i, y(v))
                    if (path == null) path = Path().apply { moveTo(p.x, p.y) } else path!!.lineTo(p.x, p.y)
                    drawCircle(C.Blue, 4.dp.toPx(), p)
                }
            }
            path?.let { drawPath(it, C.Blue, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)) }
        }
        Row(Modifier.fillMaxWidth()) { labels.forEach { Text(it, style = T.Label, modifier = Modifier.weight(1f)) } }
    }
}

/** Cumplimiento: verde completadas, rojo vencidas sin completar, gris futuras/pendientes. Descansos fuera. */
@Composable
fun ComplianceDonut(done: Int, missed: Int, pending: Int, modifier: Modifier = Modifier) {
    val total = done + missed + pending
    Box(modifier.size(132.dp).semantics { contentDescription = "$done completadas, $missed vencidas, $pending pendientes" }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            val inset = stroke / 2
            val sz = Size(size.width - stroke, size.height - stroke)
            if (total == 0) { drawArc(C.Control, 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(stroke)); return@Canvas }
            var start = -90f
            listOf(done to C.Green, missed to C.Red, pending to C.Grey).forEach { (n, col) ->
                if (n > 0) {
                    val sweep = 360f * n / total
                    drawArc(col, start + 1.5f, (sweep - 3f).coerceAtLeast(1f), false, Offset(inset, inset), sz, style = Stroke(stroke, cap = StrokeCap.Butt))
                    start += sweep
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$done/$total", style = T.Number)
            Text("hechas", style = T.Label)
        }
    }
}
