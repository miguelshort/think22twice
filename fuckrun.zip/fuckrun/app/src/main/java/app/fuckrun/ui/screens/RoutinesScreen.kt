package app.fuckrun.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.*
import app.fuckrun.data.db.PlannedSessionEntity
import app.fuckrun.data.db.RoutineEntity
import app.fuckrun.data.db.RunKind
import app.fuckrun.domain.*
import app.fuckrun.reminders.Reminders
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

fun stateColor(s: PlanState) = when (s) { PlanState.DONE -> C.Green; PlanState.MISSED -> C.Red; PlanState.PENDING -> C.Grey; PlanState.REST -> C.Control }
fun stateLabel(s: PlanState) = when (s) { PlanState.DONE -> "Completada"; PlanState.MISSED -> "Vencida"; PlanState.PENDING -> "Pendiente"; PlanState.REST -> "Descanso" }

@Composable
fun RoutinesScreen(nav: NavController) {
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val planned by remember { g.routines.planned() }.collectAsStateWithLifecycle(emptyList())
    val routines by remember { g.routines.routines() }.collectAsStateWithLifecycle(emptyList())
    var monthView by remember { mutableStateOf(false) }
    var anchor by remember { mutableStateOf(LocalDate.now()) }
    val today = LocalDate.now()

    val weekStart = anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val (from, to) = if (monthView) YearMonth.from(anchor).let { it.atDay(1) to it.atEndOfMonth() } else weekStart to weekStart.plusDays(6)
    val comp = compliance(planned, from, to, today)

    fun actions(p: PlannedSessionEntity) = plannedActions(p, sheet, nav, scope, ctx)

    ScreenScaffold("Rutinas", header = {
        Row(Modifier.clip(RoundedCornerShape(50)).background(C.Control).clickable {
            sheet.pick("Vista", listOf(false, true), { if (it) "Mensual" else "Semanal" }, monthView) { monthView = it }
        }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (monthView) "Mensual" else "Semanal", style = T.BodyStrong); Icon(Icons.Rounded.ExpandMore, null, tint = C.Text)
        }
    }) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.ChevronLeft, "Anterior", tint = C.Text, modifier = Modifier.clip(CircleShape).background(C.Control)
                    .clickable { anchor = if (monthView) anchor.minusMonths(1) else anchor.minusWeeks(1) }.padding(8.dp))
                Text(if (monthView) Fmt.month(YearMonth.from(anchor)) else "${Fmt.date(from)} – ${Fmt.date(to)}", style = T.BodyStrong,
                    textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                Icon(Icons.Rounded.ChevronRight, "Siguiente", tint = C.Text, modifier = Modifier.clip(CircleShape).background(C.Control)
                    .clickable { anchor = if (monthView) anchor.plusMonths(1) else anchor.plusWeeks(1) }.padding(8.dp))
            }
        }
        item {
            FCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ComplianceDonut(comp.done, comp.missed, comp.pending)
                    Spacer(Modifier.width(16.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${comp.done} completadas", style = T.Body.copy(color = C.Green))
                        Text("${comp.missed} vencidas sin completar", style = T.Body.copy(color = C.Red))
                        Text("${comp.pending} pendientes o futuras", style = T.Body.copy(color = C.TextSec))
                        Text("Los descansos (${comp.rest}) y las sesiones futuras no cuentan como fallos.", style = T.Label)
                    }
                }
            }
        }
        if (!monthView) {
            (0..6).forEach { i ->
                val day = weekStart.plusDays(i.toLong())
                val list = planned.filter { it.epochDay == day.toEpochDay() }
                item(key = "d$i") {
                    Column {
                        Text((if (day == today) "Hoy · " else "") + Fmt.dateLong(day), style = T.Label.copy(color = if (day == today) C.Text else C.TextSec), modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
                        if (list.isEmpty()) Text("Sin planificar", style = T.Label, modifier = Modifier.padding(start = 4.dp))
                        list.forEach { p -> PlannedRow(p) { actions(p) } }
                    }
                }
            }
        } else item {
            MonthGrid(YearMonth.from(anchor), planned) { day ->
                val list = planned.filter { it.epochDay == day.toEpochDay() }
                if (list.size == 1) actions(list.first()) else if (list.size > 1)
                    sheet.pick(Fmt.dateLong(day), list, { "${it.name} · ${stateLabel(it.state())}" }, null) { actions(it) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Nueva rutina", color = C.Text, icon = Icons.Rounded.Add, modifier = Modifier.weight(1f)) { nav.navigate(Routes.ROUTINE_NEW) }
                PillButton("Añadir sesión", color = C.Control, textColor = C.Text, modifier = Modifier.weight(1f)) {
                    if (routines.isEmpty()) sheet.show { Text("Primero crea una rutina.", style = T.Body) }
                    else sheet.show { PlannedEditor(null, routines, anchor) { sheet.hide() } }
                }
            }
        }
        if (routines.isNotEmpty()) {
            item { SectionTitle("Mis rutinas") }
            routines.forEach { r ->
                item(key = "r${r.id}") {
                    FCard {
                        ListRow(r.name, "${Fmt.date(LocalDate.ofEpochDay(r.startEpochDay))} – ${Fmt.date(LocalDate.ofEpochDay(r.endEpochDay))}" +
                            (r.templateId?.let { id -> " · plantilla ${Templates.all.firstOrNull { it.id == id }?.name ?: id}" } ?: ""), leading = Icons.Rounded.Repeat) {
                            sheet.show {
                                Text(r.name, style = T.Section)
                                Spacer(Modifier.height(12.dp))
                                ListRow("Eliminar rutina", "Las actividades ya registradas no se modifican", leading = Icons.Rounded.DeleteOutline, leadingTint = C.Red) {
                                    sheet.confirm("¿Eliminar ${r.name}?", "Se borrarán sus sesiones planificadas. Tu historial de actividades no cambia.", "Eliminar", C.Red) {
                                        scope.launch { g.routines.deleteRoutine(r.id) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        item { SectionTitle("Plantillas") }
        Templates.all.forEach { t ->
            item(key = t.id) {
                FCard {
                    Text("Nivel ${t.level.label}", style = T.Label)
                    Text(t.name, style = T.BodyStrong)
                    Text(t.summary, style = T.Body.copy(color = C.TextSec))
                    Text("Procedencia: ${t.source}", style = T.Label, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

@Composable
fun PlannedRow(p: PlannedSessionEntity, onClick: () -> Unit) {
    val s = p.state()
    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp).clip(RoundedCornerShape(20.dp)).background(C.Card).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(stateColor(s)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, style = T.BodyStrong)
            Text(listOfNotNull(stateLabel(s), p.targetMinutes?.let { "$it min" }, p.targetKm?.let { "${Fmt.km(it * 1000, 1)} km" },
                runCatching { Intensity.valueOf(p.intensity).label }.getOrNull()?.takeIf { s != PlanState.REST },
                p.reminderMinuteOfDay?.let { "aviso %02d:%02d".format(it / 60, it % 60) }).joinToString(" · "), style = T.Label)
        }
        Icon(Icons.Rounded.MoreHoriz, "Acciones", tint = C.TextSec)
    }
}

/** Panel de acciones de una sesión planificada (fondo desenfocado). */
fun plannedActions(p: PlannedSessionEntity, sheet: SheetController, nav: NavController, scope: kotlinx.coroutines.CoroutineScope, ctx: android.content.Context) {
    val g = FuckrunApp.graph
    val today = LocalDate.now()
    val days = (-3..21).map { today.plusDays(it.toLong()) }
    sheet.show {
        Text(p.name, style = T.Section)
        Text("${Fmt.dateLong(LocalDate.ofEpochDay(p.epochDay))} · ${stateLabel(p.state())}", style = T.Label)
        if (p.structure.isNotBlank()) Text(p.structure, style = T.Body, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(12.dp))
        if (p.type != SessionType.REST.name && p.linkedRunId == null) {
            PillButton("Empezar", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) { sheet.hide(); nav.navigate(Routes.prerun(RunKind.ROUTINE, planned = p.id)) }
            Spacer(Modifier.height(6.dp))
            ListRow("Reducir", "Parte principal un 30 % más corta", leading = Icons.Rounded.Remove) {
                sheet.hide(); scope.launch { g.routines.update(p.copy(targetMinutes = p.targetMinutes?.let { (it * 0.7).toInt().coerceAtLeast(5) }, targetKm = p.targetKm?.let { it * 0.7 },
                    intensity = if (p.intensity == Intensity.MODERATE.name) Intensity.EASY.name else p.intensity)) }
            }
            ListRow("Cambiar por caminata o descanso", leading = Icons.Rounded.SwapHoriz) {
                sheet.pick("Cambiar por", listOf(SessionType.WALK, SessionType.REST), { it.label }, null) { t ->
                    scope.launch { g.routines.update(p.copy(type = t.name, name = t.label, intensity = Intensity.EASY.name, structure = if (t == SessionType.WALK) "${p.targetMinutes ?: 30} min caminando a paso vivo" else "")) }
                }
            }
            ListRow("Posponer o reprogramar", leading = Icons.Rounded.EventRepeat) {
                sheet.pick("Nuevo día", days.filter { it >= today }, { Fmt.dateLong(it) }, null) { d -> scope.launch { g.routines.reschedule(p, d); Reminders.rescheduleAll(ctx) } }
            }
            ListRow("Recordatorio", p.reminderMinuteOfDay?.let { "%02d:%02d".format(it / 60, it % 60) } ?: "Sin recordatorio", leading = Icons.Rounded.NotificationsNone) {
                sheet.pick("Hora del aviso", listOf<Int?>(null) + (6..22).map { it * 60 }, { it?.let { m -> "%02d:00".format(m / 60) } ?: "Sin recordatorio" }, p.reminderMinuteOfDay) { m ->
                    scope.launch { g.routines.update(p.copy(reminderMinuteOfDay = m)); Reminders.rescheduleAll(ctx) }
                }
            }
        }
        ListRow("Editar", leading = Icons.Rounded.Edit) {
            scope.launch {
                val rs = g.routines.routines().first()
                sheet.show { PlannedEditor(p, rs, LocalDate.ofEpochDay(p.epochDay)) { sheet.hide() } }
            }
        }
        ListRow("Duplicar", leading = Icons.Rounded.ContentCopy) {
            sheet.pick("Duplicar en", days, { Fmt.dateLong(it) }, null) { d -> scope.launch { g.routines.duplicate(p, d) } }
        }
        ListRow("Eliminar", leading = Icons.Rounded.DeleteOutline, leadingTint = C.Red) {
            sheet.confirm("¿Eliminar sesión?", "Si estaba vinculada a una actividad, la actividad se conserva en tu historial.", "Eliminar", C.Red) {
                scope.launch { g.routines.delete(p.id) }
            }
        }
    }
}

/** Formulario de sesión planificada: nombre, día, tipo, objetivo, intensidad, ruta opcional. */
@Composable
fun PlannedEditor(existing: PlannedSessionEntity?, routines: List<RoutineEntity>, day0: LocalDate, onDone: () -> Unit) {
    val g = FuckrunApp.graph
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.name ?: "Rodaje suave") }
    var type by remember { mutableStateOf(existing?.type?.let { runCatching { SessionType.valueOf(it) }.getOrNull() } ?: SessionType.EASY) }
    var day by remember { mutableStateOf(day0) }
    var minutes by remember { mutableStateOf(existing?.targetMinutes?.toString() ?: "30") }
    var km by remember { mutableStateOf(existing?.targetKm?.toString() ?: "") }
    var intensity by remember { mutableStateOf(existing?.intensity?.let { runCatching { Intensity.valueOf(it) }.getOrNull() } ?: Intensity.EASY) }
    var routineId by remember { mutableStateOf(existing?.routineId ?: routines.first().id) }
    var routeId by remember { mutableStateOf(existing?.routeId) }
    var showDays by remember { mutableStateOf(false) }

    Text(if (existing == null) "Nueva sesión" else "Editar sesión", style = T.Section)
    Spacer(Modifier.height(10.dp))
    Field(name, "Nombre", singleLine = true) { name = it }
    Spacer(Modifier.height(10.dp))
    ListRow("Día", Fmt.dateLong(day), leading = Icons.Rounded.Event) { showDays = !showDays }
    if (showDays) ChoiceChips((-7..28).map { LocalDate.now().plusDays(it.toLong()) }, { "${Fmt.dayShort(it.dayOfWeek)} ${it.dayOfMonth}/${it.monthValue}" }, { it == day }) { day = it; showDays = false }
    Text("Tipo", style = T.Label, modifier = Modifier.padding(top = 8.dp))
    ChoiceChips(SessionType.entries.filter { it != SessionType.FREE }, { it.label }, { it == type }) { type = it }
    if (type != SessionType.REST) {
        Text("Objetivo de tiempo (min) y/o distancia (km)", style = T.Label, modifier = Modifier.padding(top = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) { Field(minutes, "min", singleLine = true) { minutes = it.filter(Char::isDigit).take(3) } }
            Box(Modifier.weight(1f)) { Field(km, "km (opcional)", singleLine = true) { km = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.take(5) } }
        }
        Text("Intensidad", style = T.Label, modifier = Modifier.padding(top = 8.dp))
        ChoiceChips(Intensity.entries, { it.label }, { it == intensity }) { intensity = it }
        val routes = g.routes.routes
        if (routes.isNotEmpty()) {
            Text("Ruta (opcional)", style = T.Label, modifier = Modifier.padding(top = 8.dp))
            ChoiceChips(listOf<String?>(null) + routes.map { it.id }, { id -> id?.let { g.routes.byId(it)?.name } ?: "Ninguna" }, { it == routeId }) { routeId = it }
        }
    }
    if (routines.size > 1) {
        Text("Rutina", style = T.Label, modifier = Modifier.padding(top = 8.dp))
        ChoiceChips(routines, { it.name }, { it.id == routineId }) { routineId = it.id }
    }
    Spacer(Modifier.height(16.dp))
    PillButton("Guardar", color = C.Green, modifier = Modifier.fillMaxWidth(), enabled = name.isNotBlank()) {
        scope.launch {
            val e = (existing ?: PlannedSessionEntity(routineId = routineId, name = name, epochDay = day.toEpochDay(), type = type.name)).copy(
                routineId = routineId, name = name.trim(), epochDay = day.toEpochDay(), type = type.name,
                targetMinutes = if (type == SessionType.REST) null else minutes.toIntOrNull(),
                targetKm = if (type == SessionType.REST) null else km.replace(',', '.').toDoubleOrNull(),
                intensity = intensity.name, routeId = routeId)
            if (existing == null) g.routines.add(e) else g.routines.update(e)
            onDone()
        }
    }
}

@Composable
private fun MonthGrid(month: YearMonth, planned: List<PlannedSessionEntity>, onDay: (LocalDate) -> Unit) {
    val byDay = planned.groupBy { it.epochDay }
    FCard {
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp)) { DayOfWeek.values().forEach { Text(Fmt.dayShort(it).take(1), style = T.Label, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) } }
        val first = month.atDay(1); val offset = first.dayOfWeek.value - 1
        (0 until (offset + month.lengthOfMonth() + 6) / 7).forEach { w ->
            Row(Modifier.fillMaxWidth()) {
                (0..6).forEach { c ->
                    val idx = w * 7 + c - offset
                    Column(Modifier.weight(1f).padding(vertical = 6.dp).clip(RoundedCornerShape(10.dp))
                        .clickable(enabled = idx in 0 until month.lengthOfMonth()) { onDay(first.plusDays(idx.toLong())) },
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        if (idx in 0 until month.lengthOfMonth()) {
                            val d = first.plusDays(idx.toLong())
                            Text("${idx + 1}", style = T.Label.copy(color = if (d == LocalDate.now()) C.Text else C.TextSec))
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.height(8.dp)) {
                                byDay[d.toEpochDay()].orEmpty().take(3).forEach { p ->
                                    val s = p.state()
                                    Box(Modifier.size(6.dp).clip(CircleShape).background(if (s == PlanState.REST) Color.Transparent else stateColor(s)))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
