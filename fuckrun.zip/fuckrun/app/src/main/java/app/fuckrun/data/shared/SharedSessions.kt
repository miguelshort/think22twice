@file:OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)

package app.fuckrun.data.shared

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import app.fuckrun.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import java.security.SecureRandom

/*
 * DATOS COMPARTIDOS. Separados del almacenamiento personal (Room). Aquí SOLO viajan datos
 * del encuentro (nombre, punto de encuentro, fecha, plazas…) y la confirmación de asistencia.
 * Nunca se suben rutas, ritmos, estadísticas ni posición en directo de nadie.
 *
 * Modelo Firestore (reglas en firebase/firestore.rules):
 *   sessions/{id}                     datos del encuentro
 *   sessions/{id}/attendees/{uid}     confirmación (legible por el organizador y por el propio usuario)
 *   invites/{code}                    { sessionId }  — permite unirse con código sin poder listar sesiones
 *   users/{uid}/joined/{sessionId}    índice personal de sesiones aceptadas
 */

enum class SessionStatus { SCHEDULED, CANCELLED }

data class SharedSession(
    val id: String = "",
    val name: String = "",
    val organizerUid: String = "",
    val organizerName: String = "",
    val club: String = "",
    val city: String = "",
    val province: String = "",
    val meetingLat: Double = 0.0,
    val meetingLon: Double = 0.0,
    val meetingLabel: String = "",
    val startAt: Long = 0,
    val plannedKm: Double? = null,
    val plannedMinutes: Int? = null,
    val paceHint: String = "",
    val level: String = "",
    val routeId: String? = null,
    val maxAttendees: Int? = null,
    val instructions: String = "",
    val status: SessionStatus = SessionStatus.SCHEDULED,
    val inviteCode: String = "",
    val attendeeCount: Int = 0,
    val lastChangeNote: String = "",
    val updatedAt: Long = 0,
) {
    val isFull get() = maxAttendees != null && attendeeCount >= maxAttendees
    fun phase(now: Long = System.currentTimeMillis()): String = when {
        status == SessionStatus.CANCELLED -> "Cancelada"
        startAt + 3 * 3600_000 < now -> "Finalizada"
        isFull -> "Completa"
        else -> "Próxima"
    }
}

data class Attendee(val uid: String, val name: String, val going: Boolean, val updatedAt: Long)

sealed interface SharedState {
    data object NotConfigured : SharedState
    data object SignedOut : SharedState
    data class Ready(val uid: String) : SharedState
}

class SharedError(msg: String) : Exception(msg)

class SharedSessionsRepository(private val ctx: Context) {

    private val app: FirebaseApp? = runCatching {
        if (BuildConfig.FIREBASE_API_KEY.isBlank() || BuildConfig.FIREBASE_APP_ID.isBlank() || BuildConfig.FIREBASE_PROJECT_ID.isBlank()) null
        else FirebaseApp.getApps(ctx).firstOrNull() ?: FirebaseApp.initializeApp(ctx, FirebaseOptions.Builder()
            .setApiKey(BuildConfig.FIREBASE_API_KEY).setApplicationId(BuildConfig.FIREBASE_APP_ID)
            .setProjectId(BuildConfig.FIREBASE_PROJECT_ID).build())
    }.getOrNull()

    val configured get() = app != null
    private val auth: FirebaseAuth? = app?.let { FirebaseAuth.getInstance(it) }
    private val fs: FirebaseFirestore? = app?.let { a ->
        FirebaseFirestore.getInstance(a).also {
            // Caché solo en memoria: no se deja nada compartido persistido ni escrituras "pendientes" que aparenten envío.
            it.firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build()).build()
        }
    }

    val state: Flow<SharedState> = if (auth == null) flowOf(SharedState.NotConfigured) else callbackFlow {
        val l = FirebaseAuth.AuthStateListener { a -> trySend(a.currentUser?.let { SharedState.Ready(it.uid) } ?: SharedState.SignedOut) }
        auth.addAuthStateListener(l)
        awaitClose { auth.removeAuthStateListener(l) }
    }

    /** Conectividad real del sistema (no se asume conexión). */
    val online: Flow<Boolean> = callbackFlow {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        fun now() = cm.activeNetwork?.let { cm.getNetworkCapabilities(it)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) } == true
        trySend(now())
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { trySend(now()) }
            override fun onLost(network: Network) { trySend(now()) }
            override fun onCapabilitiesChanged(network: Network, c: NetworkCapabilities) { trySend(now()) }
        }
        cm.registerDefaultNetworkCallback(cb)
        awaitClose { cm.unregisterNetworkCallback(cb) }
    }.distinctUntilChanged()

    private fun requireReady(): Pair<FirebaseFirestore, String> {
        val f = fs ?: throw SharedError("El servicio compartido no está configurado.")
        val uid = auth?.currentUser?.uid ?: throw SharedError("Necesitas activar tu perfil compartido.")
        return f to uid
    }

    /** Espera confirmación del servidor; si no llega, se informa como NO enviado. */
    private suspend fun <T> server(block: suspend () -> T): T = try {
        withTimeout(15_000) { block() }
    } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
        throw SharedError("Sin respuesta del servidor. No se ha enviado nada.")
    } catch (e: FirebaseFirestoreException) {
        throw SharedError(when (e.code) {
            FirebaseFirestoreException.Code.UNAVAILABLE -> "Sin conexión. No se ha enviado nada."
            FirebaseFirestoreException.Code.PERMISSION_DENIED -> "No tienes permiso para esta acción."
            FirebaseFirestoreException.Code.FAILED_PRECONDITION -> "No se ha podido: la sesión está ${e.message}."
            else -> "Error del servicio: ${e.code}. No se ha enviado nada."
        })
    }

    suspend fun signIn() { server { auth?.signInAnonymously()?.await() ?: throw SharedError("Servicio no configurado.") } }
    fun signOut() { auth?.signOut() }

    /** Borra la cuenta compartida: confirmaciones, índice personal y usuario. Las sesiones organizadas se cancelan. */
    suspend fun deleteAccount() {
        val (f, uid) = requireReady()
        server {
            val joined = f.collection("users").document(uid).collection("joined").get(Source.SERVER).await()
            for (d in joined.documents) {
                if (d.getString("role") == "attendee") runCatching { leave(d.id) }
                d.reference.delete().await()
            }
            val mine = f.collection("sessions").whereEqualTo("organizerUid", uid).get(Source.SERVER).await()
            for (d in mine.documents) d.reference.update(mapOf("status" to SessionStatus.CANCELLED.name, "organizerName" to "",
                "lastChangeNote" to "El organizador ha eliminado su cuenta", "updatedAt" to FieldValue.serverTimestamp())).await()
            auth?.currentUser?.delete()?.await()
        }
    }

    private fun newCode(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   // sin 0/O ni 1/I
        val r = SecureRandom()
        return (1..6).map { alphabet[r.nextInt(alphabet.length)] }.joinToString("")
    }

    private fun toMap(s: SharedSession, uid: String) = mapOf(
        "name" to s.name, "organizerUid" to uid, "organizerName" to s.organizerName, "club" to s.club,
        "city" to s.city, "province" to s.province, "meetingLat" to s.meetingLat, "meetingLon" to s.meetingLon,
        "meetingLabel" to s.meetingLabel, "startAt" to Timestamp(java.util.Date(s.startAt)), "plannedKm" to s.plannedKm,
        "plannedMinutes" to s.plannedMinutes, "paceHint" to s.paceHint, "level" to s.level, "routeId" to s.routeId,
        "maxAttendees" to s.maxAttendees, "instructions" to s.instructions, "status" to s.status.name,
        "lastChangeNote" to s.lastChangeNote, "updatedAt" to FieldValue.serverTimestamp(),
    )

    private fun fromDoc(d: DocumentSnapshot) = SharedSession(
        id = d.id, name = d.getString("name") ?: "", organizerUid = d.getString("organizerUid") ?: "",
        organizerName = d.getString("organizerName") ?: "", club = d.getString("club") ?: "",
        city = d.getString("city") ?: "", province = d.getString("province") ?: "",
        meetingLat = d.getDouble("meetingLat") ?: 0.0, meetingLon = d.getDouble("meetingLon") ?: 0.0,
        meetingLabel = d.getString("meetingLabel") ?: "", startAt = d.getTimestamp("startAt")?.toDate()?.time ?: 0,
        plannedKm = d.getDouble("plannedKm"), plannedMinutes = d.getLong("plannedMinutes")?.toInt(),
        paceHint = d.getString("paceHint") ?: "", level = d.getString("level") ?: "", routeId = d.getString("routeId"),
        maxAttendees = d.getLong("maxAttendees")?.toInt(), instructions = d.getString("instructions") ?: "",
        status = runCatching { SessionStatus.valueOf(d.getString("status") ?: "") }.getOrDefault(SessionStatus.SCHEDULED),
        inviteCode = d.getString("inviteCode") ?: "", attendeeCount = d.getLong("attendeeCount")?.toInt() ?: 0,
        lastChangeNote = d.getString("lastChangeNote") ?: "", updatedAt = d.getTimestamp("updatedAt")?.toDate()?.time ?: 0,
    )

    suspend fun create(s: SharedSession): SharedSession {
        val (f, uid) = requireReady()
        return server {
            val ref = f.collection("sessions").document()
            var code = newCode()
            f.runTransaction { tx ->
                if (tx.get(f.collection("invites").document(code)).exists()) code = newCode()
                tx.set(ref, toMap(s, uid) + mapOf("inviteCode" to code, "attendeeCount" to 0))
                tx.set(f.collection("invites").document(code), mapOf("sessionId" to ref.id, "organizerUid" to uid))
                tx.set(f.collection("users").document(uid).collection("joined").document(ref.id), mapOf("role" to "organizer"))
            }.await()
            s.copy(id = ref.id, organizerUid = uid, inviteCode = code)
        }
    }

    suspend fun update(s: SharedSession, changeNote: String) {
        val (f, uid) = requireReady()
        server { f.collection("sessions").document(s.id).set(toMap(s.copy(lastChangeNote = changeNote), uid), SetOptions.merge()).await() }
    }

    suspend fun cancel(s: SharedSession, note: String) = update(s.copy(status = SessionStatus.CANCELLED), note.ifBlank { "Sesión cancelada" })

    suspend fun findByCode(code: String): SharedSession {
        val (f, _) = requireReady()
        return server {
            val inv = f.collection("invites").document(code.trim().uppercase()).get(Source.SERVER).await()
            val sid = inv.getString("sessionId") ?: throw SharedError("No existe ninguna sesión con ese código.")
            fromDoc(f.collection("sessions").document(sid).get(Source.SERVER).await())
        }
    }

    /** Confirmar asistencia en transacción: sin inscripciones duplicadas ni superar el máximo. */
    suspend fun join(sessionId: String, displayName: String) {
        val (f, uid) = requireReady()
        server {
            val sRef = f.collection("sessions").document(sessionId)
            val aRef = sRef.collection("attendees").document(uid)
            f.runTransaction { tx ->
                val s = tx.get(sRef)
                val a = tx.get(aRef)
                if (s.getString("status") == SessionStatus.CANCELLED.name) throw FirebaseFirestoreException("cancelada", FirebaseFirestoreException.Code.FAILED_PRECONDITION)
                val alreadyGoing = a.exists() && a.getBoolean("going") == true
                if (alreadyGoing) return@runTransaction null
                val count = s.getLong("attendeeCount") ?: 0
                val max = s.getLong("maxAttendees")
                if (max != null && count >= max) throw FirebaseFirestoreException("completa", FirebaseFirestoreException.Code.FAILED_PRECONDITION)
                tx.set(aRef, mapOf("name" to displayName, "going" to true, "updatedAt" to FieldValue.serverTimestamp()))
                tx.update(sRef, "attendeeCount", count + 1)
                tx.set(f.collection("users").document(uid).collection("joined").document(sessionId), mapOf("role" to "attendee"))
                null
            }.await()
        }
    }

    suspend fun leave(sessionId: String) {
        val (f, uid) = requireReady()
        server {
            val sRef = f.collection("sessions").document(sessionId)
            val aRef = sRef.collection("attendees").document(uid)
            f.runTransaction { tx ->
                val s = tx.get(sRef); val a = tx.get(aRef)
                if (a.exists() && a.getBoolean("going") == true) {
                    tx.update(aRef, mapOf("going" to false, "updatedAt" to FieldValue.serverTimestamp()))
                    tx.update(sRef, "attendeeCount", ((s.getLong("attendeeCount") ?: 1) - 1).coerceAtLeast(0))
                }
                null
            }.await()
        }
    }

    /** Sesiones del usuario (organizadas o aceptadas), con actualizaciones en tiempo real. */
    fun mySessions(): Flow<List<SharedSession>> = state.flatMapLatest { st ->
        val f = fs
        if (st !is SharedState.Ready || f == null) flowOf(emptyList()) else callbackFlow {
            val docListeners = mutableMapOf<String, ListenerRegistration>()
            val current = mutableMapOf<String, SharedSession>()
            val idx = f.collection("users").document(st.uid).collection("joined").addSnapshotListener { snap, _ ->
                val ids = snap?.documents?.map { it.id }?.toSet() ?: return@addSnapshotListener
                (docListeners.keys - ids).forEach { docListeners.remove(it)?.remove(); current.remove(it) }
                (ids - docListeners.keys).forEach { id ->
                    docListeners[id] = f.collection("sessions").document(id).addSnapshotListener { d, _ ->
                        if (d != null && d.exists()) { current[id] = fromDoc(d); trySend(current.values.sortedBy { it.startAt }) }
                    }
                }
                trySend(current.values.sortedBy { it.startAt })
            }
            awaitClose { idx.remove(); docListeners.values.forEach { it.remove() } }
        }
    }

    fun session(id: String): Flow<SharedSession?> = fs?.let { f -> callbackFlow {
        val l = f.collection("sessions").document(id).addSnapshotListener { d, _ -> trySend(d?.takeIf { it.exists() }?.let { fromDoc(it) }) }
        awaitClose { l.remove() }
    } } ?: flowOf(null)

    /** Solo el organizador puede leer la lista (las reglas lo imponen). */
    fun attendees(sessionId: String): Flow<List<Attendee>> = fs?.let { f -> callbackFlow {
        val l = f.collection("sessions").document(sessionId).collection("attendees").addSnapshotListener { snap, _ ->
            trySend(snap?.documents?.map { Attendee(it.id, it.getString("name") ?: "", it.getBoolean("going") == true,
                it.getTimestamp("updatedAt")?.toDate()?.time ?: 0) } ?: emptyList())
        }
        awaitClose { l.remove() }
    } } ?: flowOf(emptyList())

    fun myAttendance(sessionId: String): Flow<Boolean> = state.flatMapLatest { st ->
        val f = fs
        if (st !is SharedState.Ready || f == null) flowOf(false) else callbackFlow {
            val l = f.collection("sessions").document(sessionId).collection("attendees").document(st.uid)
                .addSnapshotListener { d, _ -> trySend(d?.getBoolean("going") == true) }
            awaitClose { l.remove() }
        }
    }

    fun currentUid() = auth?.currentUser?.uid
}
