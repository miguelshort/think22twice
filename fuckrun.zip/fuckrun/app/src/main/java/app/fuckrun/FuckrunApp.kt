package app.fuckrun

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import app.fuckrun.data.*
import app.fuckrun.data.db.AppDatabase
import app.fuckrun.data.shared.SharedSessionsRepository
import org.osmdroid.config.Configuration

/** Contenedor sencillo de dependencias. */
class AppGraph(app: Application) {
    val db = AppDatabase.build(app)
    val clock = DeviceClock(app)
    val runs = RunRepository(db, clock)
    val routines = RoutineRepository(db)
    val profile = ProfileStore(app)
    val municipalities by lazy { MunicipalityIndex(app) }
    val routes by lazy { RouteCatalog(app) }
    val shared = SharedSessionsRepository(app)
}

class FuckrunApp : Application() {
    lateinit var graph: AppGraph
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        graph = AppGraph(this)
        Configuration.getInstance().apply {
            load(this@FuckrunApp, getSharedPreferences("osmdroid", MODE_PRIVATE))
            userAgentValue = "fuckrun/${BuildConfig.VERSION_NAME} (${BuildConfig.APPLICATION_ID})"
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SESSION, "Sesión activa", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Aviso visible mientras se registra una carrera"
        })
        nm.createNotificationChannel(NotificationChannel(CH_ALERTS, "Avisos de la sesión", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Pérdida de señal, GPS desactivado o batería baja durante una carrera"
        })
        nm.createNotificationChannel(NotificationChannel(CH_REMINDERS, "Recordatorios de rutina", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_CLUB, "Cambios en sesiones conjuntas", NotificationManager.IMPORTANCE_DEFAULT))
    }

    companion object {
        const val CH_SESSION = "session"
        const val CH_ALERTS = "session_alerts"
        const val CH_REMINDERS = "reminders"
        const val CH_CLUB = "club"
        lateinit var instance: FuckrunApp
            private set
        val graph get() = instance.graph
    }
}
