package app.fuckrun.data.db

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/*
 * ALMACENAMIENTO PERSONAL (solo en el dispositivo). Nada de esta base de datos se sube
 * al servicio compartido. Los datos compartidos viven en data/shared y en Firestore.
 */

object RunStatus { const val RECORDING = "RECORDING"; const val PAUSED = "PAUSED"; const val ENDED_UNSAVED = "ENDED_UNSAVED"; const val FINISHED = "FINISHED" }
object RunSource { const val GPS = "GPS"; const val MANUAL = "MANUAL" }
object RunKind { const val FREE = "FREE"; const val ROUTINE = "ROUTINE"; const val ROUTE = "ROUTE"; const val SHARED = "SHARED" }
object EventType { const val START = "START"; const val PAUSE = "PAUSE"; const val RESUME = "RESUME"; const val STOP = "STOP"
    const val INTERRUPTED = "INTERRUPTED"; const val SIGNAL_LOST = "SIGNAL_LOST"; const val SIGNAL_BACK = "SIGNAL_BACK"
    const val GPS_OFF = "GPS_OFF"; const val PERMISSION_LOST = "PERMISSION_LOST"; const val BATTERY_LOW = "BATTERY_LOW"; const val TIME_CHANGED = "TIME_CHANGED" }

@Entity(tableName = "runs")
data class RunEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAtWall: Long,
    val endedAtWall: Long? = null,
    val status: String,
    val source: String = RunSource.GPS,
    val kind: String = RunKind.FREE,
    val plannedSessionId: Long? = null,
    val routeId: String? = null,
    val sharedSessionId: String? = null,
    val sharedSessionName: String? = null,
    val note: String = "",
    // Resumen calculado al terminar (null = sin datos suficientes; nunca valores inventados)
    val distanceM: Double? = null,
    val elapsedMs: Long = 0,
    val activeMs: Long = 0,
    val avgSpeedMps: Double? = null,
    val maxSpeedMps: Double? = null,
    val minMovingSpeedMps: Double? = null,
    val lostMs: Long = 0,           // tramo perdido por cierre de la app / reinicio
    val gapCount: Int = 0,
    val currentSegment: Int = 0,
)

@Entity(tableName = "points", indices = [Index("runId")],
    foreignKeys = [ForeignKey(entity = RunEntity::class, parentColumns = ["id"], childColumns = ["runId"], onDelete = ForeignKey.CASCADE)])
data class PointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val runId: Long,
    val segment: Int,
    val wallMs: Long,
    val monoMs: Long,       // elapsedRealtime del fijo (solo comparable dentro del mismo arranque)
    val bootCount: Int,
    val lat: Double,
    val lon: Double,
    val accuracyM: Float,
    val altitudeM: Double?,
)

@Entity(tableName = "events", indices = [Index("runId")],
    foreignKeys = [ForeignKey(entity = RunEntity::class, parentColumns = ["id"], childColumns = ["runId"], onDelete = ForeignKey.CASCADE)])
data class EventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val runId: Long,
    val type: String,
    val wallMs: Long,
    val monoMs: Long,
    val bootCount: Int,
    val detail: String = "",
)

@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val kind: String,           // WEEKLY, MONTHLY, CUSTOM
    val startEpochDay: Long,
    val endEpochDay: Long,
    val templateId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "planned", indices = [Index("routineId"), Index("epochDay")],
    foreignKeys = [ForeignKey(entity = RoutineEntity::class, parentColumns = ["id"], childColumns = ["routineId"], onDelete = ForeignKey.CASCADE)])
data class PlannedSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val routineId: Long,
    val name: String,
    val epochDay: Long,
    val type: String,           // SessionType.name
    val targetMinutes: Int? = null,
    val targetKm: Double? = null,
    val intensity: String = "EASY",
    val structure: String = "",
    val routeId: String? = null,
    val reminderMinuteOfDay: Int? = null,
    val skipped: Boolean = false,
    val linkedRunId: Long? = null,
)

@Entity(tableName = "favorite_routes")
data class FavoriteRouteEntity(@PrimaryKey val routeId: String, val addedAt: Long = System.currentTimeMillis())

@Dao
interface RunDao {
    @Insert suspend fun insert(run: RunEntity): Long
    @Update suspend fun update(run: RunEntity)
    @Query("SELECT * FROM runs WHERE id = :id") suspend fun get(id: Long): RunEntity?
    @Query("SELECT * FROM runs WHERE id = :id") fun observe(id: Long): Flow<RunEntity?>
    @Query("SELECT * FROM runs WHERE status = 'FINISHED' ORDER BY startedAtWall DESC") fun finished(): Flow<List<RunEntity>>
    @Query("SELECT * FROM runs WHERE status != 'FINISHED' ORDER BY startedAtWall DESC LIMIT 1") suspend fun unfinished(): RunEntity?
    @Query("DELETE FROM runs WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM runs") suspend fun deleteAll()

    @Insert suspend fun insertPoint(p: PointEntity)
    @Query("SELECT * FROM points WHERE runId = :runId ORDER BY segment, id") suspend fun points(runId: Long): List<PointEntity>
    @Query("SELECT * FROM points WHERE runId = :runId ORDER BY id DESC LIMIT 1") suspend fun lastPoint(runId: Long): PointEntity?

    @Insert suspend fun insertEvent(e: EventEntity)
    @Query("SELECT * FROM events WHERE runId = :runId ORDER BY id") suspend fun events(runId: Long): List<EventEntity>
}

@Dao
interface RoutineDao {
    @Insert suspend fun insert(r: RoutineEntity): Long
    @Update suspend fun update(r: RoutineEntity)
    @Query("DELETE FROM routines WHERE id = :id") suspend fun delete(id: Long)
    @Query("SELECT * FROM routines ORDER BY startEpochDay DESC") fun routines(): Flow<List<RoutineEntity>>
    @Insert suspend fun insertPlanned(p: PlannedSessionEntity): Long
    @Insert suspend fun insertPlannedAll(p: List<PlannedSessionEntity>)
    @Update suspend fun updatePlanned(p: PlannedSessionEntity)
    @Query("DELETE FROM planned WHERE id = :id") suspend fun deletePlanned(id: Long)
    @Query("SELECT * FROM planned WHERE id = :id") suspend fun planned(id: Long): PlannedSessionEntity?
    @Query("SELECT * FROM planned ORDER BY epochDay") fun allPlanned(): Flow<List<PlannedSessionEntity>>
    @Query("SELECT * FROM planned") suspend fun allPlannedOnce(): List<PlannedSessionEntity>
    @Query("SELECT * FROM planned WHERE linkedRunId = :runId LIMIT 1") suspend fun byRun(runId: Long): PlannedSessionEntity?
    @Query("UPDATE planned SET linkedRunId = NULL WHERE linkedRunId = :runId") suspend fun unlinkRun(runId: Long)
    @Query("DELETE FROM routines") suspend fun deleteAll()
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorite_routes") fun all(): Flow<List<FavoriteRouteEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun add(f: FavoriteRouteEntity)
    @Query("DELETE FROM favorite_routes WHERE routeId = :id") suspend fun remove(id: String)
    @Query("DELETE FROM favorite_routes") suspend fun deleteAll()
}

@Database(entities = [RunEntity::class, PointEntity::class, EventEntity::class, RoutineEntity::class,
    PlannedSessionEntity::class, FavoriteRouteEntity::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun runs(): RunDao
    abstract fun routines(): RoutineDao
    abstract fun favorites(): FavoriteDao

    companion object {
        fun build(ctx: Context) = Room.databaseBuilder(ctx, AppDatabase::class.java, "fuckrun-personal.db").build()
    }
}
