package app.fuckrun.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.*
import app.fuckrun.data.db.FavoriteRouteEntity
import app.fuckrun.data.db.RunKind
import app.fuckrun.domain.*
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.launch

@SuppressLint("MissingPermission")
@Composable
fun RoutesScreen(nav: NavController) {
    val ctx = LocalContext.current
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    val favs by remember { g.db.favorites().all() }.collectAsStateWithLifecycle(emptyList())
    var filter by remember { mutableStateOf(RouteFilter()) }
    var me by remember { mutableStateOf<LatLon?>(null) }
    var onlyFavs by remember { mutableStateOf(false) }
    val a = settings.answers
    val municipality = a.municipality?.let { m -> g.municipalities.all.firstOrNull { it.name == m && it.province == a.province } }

    fun locate() {
        val lm = ctx.getSystemService(LocationManager::class.java)
        if (!LocationManagerCompat.isLocationEnabled(lm)) { sheet.show { Text("La ubicación del dispositivo está desactivada.", style = T.Body) }; return }
        val provider = if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER else LocationManager.GPS_PROVIDER
        // Lectura puntual: no queda ningún seguimiento activo.
        LocationManagerCompat.getCurrentLocation(lm, provider, null as android.os.CancellationSignal?, ContextCompat.getMainExecutor(ctx)) { loc ->
            if (loc != null) me = LatLon(loc.latitude, loc.longitude)
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res -> if (res.values.any { it }) locate() }

    val base = g.routes.forMunicipality(municipality).let { list -> if (onlyFavs) list.filter { r -> favs.any { it.routeId == r.id } } else list }
    val ranked = g.routes.rank(base, a, filter, me)
    val activeFilters = listOfNotNull(filter.minKm, filter.maxKm, filter.surface, filter.maxDistanceFromMeKm).size + if (filter.flatOnly) 1 else 0

    ScreenScaffold("Rutas") {
        item {
            FCard(onClick = {
                sheet.show {
                    Text("Municipio", style = T.Section)
                    Spacer(Modifier.height(10.dp))
                    MunicipalityPicker(null) { m -> if (m != null) { scope.launch { g.profile.update { it.copy(answers = it.answers.copy(municipality = m.name, province = m.province)) } }; sheet.hide() } }
                }
            }) {
                Text("Zona", style = T.Label)
                Text(municipality?.name ?: "Elige municipio", style = T.Section)
                Text(municipality?.province ?: "Sin necesidad de compartir tu ubicación", style = T.Label)
            }
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Chip(if (me == null) "Usar mi ubicación (opcional)" else "Ubicación usada", Icons.Rounded.MyLocation, selected = me != null) {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) locate()
                    else perm.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                }
                Chip(if (activeFilters > 0) "Filtros ($activeFilters)" else "Filtros", Icons.Rounded.Tune, selected = activeFilters > 0) {
                    sheet.show { FilterPanel(filter, g.routes.surfaces, me != null) { filter = it; sheet.hide() } }
                }
                Chip("Favoritos", Icons.Rounded.Star, selected = onlyFavs) { onlyFavs = !onlyFavs }
            }
        }
        if (ranked.isEmpty()) {
            item {
                FCard {
                    Icon(Icons.Rounded.Explore, null, tint = C.TextSec)
                    Spacer(Modifier.height(8.dp))
                    Text(if (base.isEmpty() && !onlyFavs) "Todavía no tenemos recorridos verificados para esta zona" else "Ningún recorrido cumple estos filtros", style = T.Section)
                    Spacer(Modifier.height(6.dp))
                    Text("Mientras tanto, puedes correr por tiempo o distancia donde te resulte cómodo. Un mapa por sí solo no garantiza que un recorrido sea adecuado para correr.", style = T.Body.copy(color = C.TextSec))
                }
            }
            item { ProposalCard(RecommendationEngine.proposal(a), onStart = { nav.navigate(Routes.prerun()) }) }
        } else {
            item {
                RunMap(emptyList(), Modifier.fillMaxWidth().height(220.dp),
                    markers = ranked.map { MapMarker(LatLon(it.route.start.lat, it.route.start.lon), it.route.name) })
            }
            item { Text(g.routes.criterion(a), style = T.Label, modifier = Modifier.padding(horizontal = 4.dp)) }
            ranked.forEach { rr ->
                item(key = rr.route.id) {
                    val r = rr.route
                    val fav = favs.any { it.routeId == r.id }
                    FCard(onClick = { sheet.show { RouteDetail(r, fav, onFav = { scope.launch { if (fav) g.db.favorites().remove(r.id) else g.db.favorites().add(FavoriteRouteEntity(r.id)) } },
                        onStart = { sheet.hide(); nav.navigate(Routes.prerun(RunKind.ROUTE, route = r.id)) }) } }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(r.name, style = T.BodyStrong)
                                Text(listOfNotNull("${Fmt.km(r.distanceM, 1)} km", r.shape.label, r.surface, rr.distanceFromMeM?.let { "a ${Fmt.km(it, 1)} km" }).joinToString(" · "), style = T.Label)
                            }
                            if (fav) Icon(Icons.Rounded.Star, "Favorita", tint = C.Blue)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Chip(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(50)).background(if (selected) C.Text else C.Control).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = if (selected) C.OnColor else C.Text, modifier = Modifier.size(16.dp))
        Text(" $text", style = T.Label.copy(color = if (selected) C.OnColor else C.Text), maxLines = 1)
    }
}

@Composable
private fun FilterPanel(f0: RouteFilter, surfaces: List<String>, hasLocation: Boolean, onApply: (RouteFilter) -> Unit) {
    var f by remember { mutableStateOf(f0) }
    Text("Filtros", style = T.Section)
    Text("Distancia", style = T.Label, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
    val ranges = listOf(null to null, null to 5.0, 5.0 to 10.0, 10.0 to null)
    ChoiceChips(ranges, { (lo, hi) -> when { lo == null && hi == null -> "Cualquiera"; lo == null -> "Hasta ${hi!!.toInt()} km"; hi == null -> "Más de ${lo.toInt()} km"; else -> "${lo.toInt()}–${hi.toInt()} km" } },
        { it == (f.minKm to f.maxKm) }) { f = f.copy(minKm = it.first, maxKm = it.second) }
    if (surfaces.isNotEmpty()) {
        Text("Superficie", style = T.Label, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
        ChoiceChips(listOf<String?>(null) + surfaces, { it ?: "Cualquiera" }, { it == f.surface }) { f = f.copy(surface = it) }
    }
    Text("Desnivel", style = T.Label, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
    ChoiceChips(listOf(false, true), { if (it) "Solo llanos (dato fiable)" else "Cualquiera" }, { it == f.flatOnly }) { f = f.copy(flatOnly = it) }
    Text("Cercanía", style = T.Label, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
    if (!hasLocation) Text("Comparte tu ubicación para filtrar por cercanía.", style = T.Label)
    else ChoiceChips(listOf<Double?>(null, 2.0, 5.0, 10.0), { it?.let { d -> "≤ ${d.toInt()} km" } ?: "Cualquiera" }, { it == f.maxDistanceFromMeKm }) { f = f.copy(maxDistanceFromMeKm = it) }
    Spacer(Modifier.height(16.dp))
    PillButton("Aplicar", color = C.Text, modifier = Modifier.fillMaxWidth()) { onApply(f) }
    Spacer(Modifier.height(8.dp))
    PillButton("Quitar filtros", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { onApply(RouteFilter()) }
}

@Composable
private fun RouteDetail(r: VerifiedRoute, fav: Boolean, onFav: () -> Unit, onStart: () -> Unit) {
    Text(r.name, style = T.Section)
    Text("${r.municipality} · ${r.province}", style = T.Label)
    Spacer(Modifier.height(10.dp))
    RunMap(listOf(r.track), Modifier.fillMaxWidth().height(200.dp), markers = listOf(MapMarker(LatLon(r.start.lat, r.start.lon), "Inicio")), showGaps = false)
    Spacer(Modifier.height(10.dp))
    Detail("Distancia", "${Fmt.km(r.distanceM, 2)} km")
    Detail("Tipo", r.shape.label)
    Detail("Superficie", r.surface ?: "Sin dato verificado")
    Detail("Desnivel", r.elevationGainM?.let { "${it.toInt()} m positivos" } ?: "Sin dato fiable")
    Detail("Punto de inicio", r.start.label)
    if (r.verifiedAttributes.isNotEmpty()) Detail("Características verificadas", r.verifiedAttributes.joinToString(", "))
    Detail("Fuente", "${r.source.name} (${r.source.license}) · revisada el ${r.reviewedAt}")
    Detail("Restricciones o incidencias conocidas", if (r.incidents.isEmpty()) "Ninguna registrada a fecha de revisión" else r.incidents.joinToString("\n") { "${it.date}: ${it.text}" })
    Text("No describimos un recorrido como seguro, iluminado o accesible salvo que esté verificado. Comprueba el estado antes de salir.", style = T.Label, modifier = Modifier.padding(top = 6.dp))
    Spacer(Modifier.height(14.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PillButton(if (fav) "Quitar favorito" else "Favorito", color = C.Control, textColor = C.Text, icon = Icons.Rounded.Star, modifier = Modifier.weight(1f)) { onFav() }
        PillButton("Empezar", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.weight(1f)) { onStart() }
    }
}
