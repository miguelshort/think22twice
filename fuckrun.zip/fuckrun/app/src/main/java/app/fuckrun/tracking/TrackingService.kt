package app.fuckrun.tracking

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import app.fuckrun.FuckrunApp
import app.fuckrun.MainActivity
import app.fuckrun.R
import app.fuckrun.data.db.*
import app.fuckrun.data.toSample
import app.fuckrun.domain.Fmt
import app.fuckrun.domain.metrics.RunMetrics
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class SignalQuality(val label: String) { NONE("Sin señal"), WEAK("Señal débil"), OK("Señal aceptable"), GOOD("Señal buena") }
enum class Warning(val text: String) {
    SIGNAL_LOST("Sin señal GPS: el tramo sin datos no se dibujará como recorrido."),
    GPS_OFF("La ubicación está desactivada. Actívala para seguir registrando."),
    PERMISSION_LOST("Se ha retirado el permiso de ubicación. La captura está detenida."),
    BATTERY_LOW("Batería baja. La sesión sigue grabando."),
    TIME_CHANGED("Ha cambiado la hora del sistema. Los tiempos se miden con un reloj interno y no se ven afectados."),
}

fun signalFor(accuracy: Float?): SignalQuality = when {
    accuracy == null -> SignalQuality.NONE
    accuracy <= 10f -> SignalQuality.GOOD
    accuracy <= RunMetrics.MAX_ACCURACY_M -> SignalQuality.OK
    else -> SignalQuality.WEAK
}

data class LiveRun(
    val runId: Long,
    val status: String,
    val signal: SignalQuality,
    val stats: RunMetrics.Stats?,
    val warnings: Set<Warning>,
    val kindLabel: String,
)

/** Estado observable del registro en curso. */
object Tracking {
    internal val _live = MutableStateFlow<LiveRun?>(null)
    val live = _live.asStateFlow()
    internal val _ended = MutableStateFlow<Long?>(null)
    /** id de la sesión recién terminada, pendiente de guardar o descartar. */
    val ended = _ended.asStateFlow()
    fun consumeEnded() { _ended.value = null }

    const val ACTION_START = "start"; const val ACTION_CONTINUE = "continue"
    const val ACTION_PAUSE = "pause"; const val ACTION_RESUME = "resume"; const val ACTION_STOP = "stop"

    fun start(ctx: Context, kind: String, plannedId: Long? = null, routeId: String? = null, sharedId: String? = null, sharedName: String? = null) =
        send(ctx, ACTION_START) { putExtra("kind", kind); plannedId?.let { putExtra("planned", it) }; putExtra("route", routeId)
            putExtra("shared", sharedId); putExtra("sharedName", sharedName) }
    fun continueRun(ctx: Context, runId: Long) = send(ctx, ACTION_CONTINUE) { putExtra("runId", runId) }
    fun pause(ctx: Context) = send(ctx, ACTION_PAUSE) {}
    fun resume(ctx: Context) = send(ctx, ACTION_RESUME) {}
    fun stop(ctx: Context) = send(ctx, ACTION_STOP) {}

    private fun send(ctx: Context, action: String, extras: Intent.() -> Unit) {
        val i = Intent(ctx, TrackingService::class.java).setAction(action).apply(extras)
        if (action == ACTION_START || action == ACTION_CONTINUE) ContextCompat.startForegroundService(ctx, i) else ctx.startService(i)
    }

    fun hasLocationPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
}

/**
 * Servicio en primer plano de tipo "location". Solo existe mientras hay una sesión iniciada por el usuario:
 * se detiene al terminar o descartar. No se reinicia solo (START_NOT_STICKY): si el sistema lo cierra,
 * la app ofrece recuperar lo guardado la próxima vez que se abra.
 */
class TrackingService : LifecycleService() {
    private val graph get() = FuckrunApp.graph
    private val repo get() = graph.runs
    private lateinit var lm: LocationManager
    private val mutex = Mutex()

    private var active: RunEntity? = null
    private val events = mutableListOf<EventEntity>()
    private val samples = mutableListOf<RunMetrics.Sample>()
    private var lastFix: Location? = null
    private var lastFixMono = 0L
    private var gapRefMono = 0L      // referencia para detectar huecos (último fijo o reanudación)
    private var signalLostFlag = false
    private val warnings = mutableSetOf<Warning>()
    private var ticker: Job? = null
    private var listening = false

    private val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) { lifecycleScope.launch { onFix(loc) } }
        override fun onProviderDisabled(provider: String) { lifecycleScope.launch { onGpsOff() } }
        override fun onProviderEnabled(provider: String) { warnings.remove(Warning.GPS_OFF); publish() }
        @Deprecated("Deprecated in API") override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {}
    }

    private val systemReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = active?.id ?: return
            lifecycleScope.launch {
                when (i.action) {
                    Intent.ACTION_BATTERY_LOW -> { warnings += Warning.BATTERY_LOW; logEvent(EventType.BATTERY_LOW); alert(Warning.BATTERY_LOW) }
                    Intent.ACTION_BATTERY_OKAY -> warnings -= Warning.BATTERY_LOW
                    Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> { warnings += Warning.TIME_CHANGED; logEvent(EventType.TIME_CHANGED, i.action ?: "") }
                }
                publish()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LocationManager::class.java)
        val f = IntentFilter().apply { addAction(Intent.ACTION_BATTERY_LOW); addAction(Intent.ACTION_BATTERY_OKAY)
            addAction(Intent.ACTION_TIME_CHANGED); addAction(Intent.ACTION_TIMEZONE_CHANGED) }
        ContextCompat.registerReceiver(this, systemReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent == null) { stopSelf(); return START_NOT_STICKY }   // reinicio sin intención explícita: no rastrear
        when (intent.action) {
            Tracking.ACTION_START, Tracking.ACTION_CONTINUE -> {
                goForeground("Preparando el registro…")
                lifecycleScope.launch {
                    mutex.withLock {
                        val id = if (intent.action == Tracking.ACTION_START) repo.startRun(
                            intent.getStringExtra("kind") ?: RunKind.FREE,
                            intent.getLongExtra("planned", -1).takeIf { it > 0 },
                            intent.getStringExtra("route"), intent.getStringExtra("shared"), intent.getStringExtra("sharedName"),
                        ) else intent.getLongExtra("runId", -1)
                        load(id)
                        if (intent.action == Tracking.ACTION_CONTINUE) resumeInternal()
                    }
                    startLocation()
                    startTicker()
                }
            }
            Tracking.ACTION_PAUSE -> lifecycleScope.launch { mutex.withLock { pauseInternal() } }
            Tracking.ACTION_RESUME -> lifecycleScope.launch { mutex.withLock { resumeInternal() } }
            Tracking.ACTION_STOP -> lifecycleScope.launch { mutex.withLock { stopInternal() } }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private suspend fun load(id: Long) {
        active = repo.get(id)
        events.clear(); events += repo.events(id)
        samples.clear(); samples += repo.points(id).map { it.toSample() }
        gapRefMono = repo.clock.mono()
        publish()
    }

    private fun goForeground(text: String) {
        ServiceCompat.startForeground(this, NOTIF_ID, notification(text),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0)
    }

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (listening) return
        if (!Tracking.hasLocationPermission(this)) { lifecycleScope.launch { onPermissionLost() }; return }
        try {
            if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) lifecycleScope.launch { onGpsOff() }
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper())
            listening = true
        } catch (e: SecurityException) { lifecycleScope.launch { onPermissionLost() } }
    }

    private fun stopLocation() { if (listening) lm.removeUpdates(listener); listening = false }

    private suspend fun logEvent(type: String, detail: String = "") {
        val r = active ?: return
        val e = EventEntity(runId = r.id, type = type, wallMs = repo.clock.wall(), monoMs = repo.clock.mono(), bootCount = repo.clock.boot(), detail = detail)
        graph.db.runs().insertEvent(e); events += e
    }

    private suspend fun newSegment() {
        val r = active ?: return
        val updated = r.copy(currentSegment = r.currentSegment + 1); active = updated; repo.update(updated)
    }

    private suspend fun onFix(loc: Location) = mutex.withLock {
        val r = active ?: return@withLock
        lastFix = loc; lastFixMono = repo.clock.mono(); gapRefMono = lastFixMono
        warnings.remove(Warning.GPS_OFF)
        if (r.status != RunStatus.RECORDING) { publish(); return@withLock }
        if (signalLostFlag) {   // vuelve la señal: segmento nuevo, el hueco no se une
            signalLostFlag = false; warnings.remove(Warning.SIGNAL_LOST)
            newSegment(); logEvent(EventType.SIGNAL_BACK)
        }
        val cur = active!!
        val monoFix = loc.elapsedRealtimeNanos / 1_000_000
        val p = PointEntity(runId = cur.id, segment = cur.currentSegment, wallMs = loc.time, monoMs = monoFix, bootCount = repo.clock.boot(),
            lat = loc.latitude, lon = loc.longitude, accuracyM = if (loc.hasAccuracy()) loc.accuracy else 999f,
            altitudeM = if (loc.hasAltitude()) loc.altitude else null)
        repo.addPoint(p)                // guardado incremental de cada punto
        samples += p.toSample()
        publish()
    }

    private suspend fun onGpsOff() = mutex.withLock {
        if (active == null || Warning.GPS_OFF in warnings) return@withLock
        warnings += Warning.GPS_OFF; logEvent(EventType.GPS_OFF); alert(Warning.GPS_OFF); publish()
    }

    private suspend fun onPermissionLost() = mutex.withLock {
        if (active == null) return@withLock
        warnings += Warning.PERMISSION_LOST; logEvent(EventType.PERMISSION_LOST)
        stopLocation(); alert(Warning.PERMISSION_LOST); publish()
    }

    private suspend fun pauseInternal() {
        val r = active ?: return
        if (r.status != RunStatus.RECORDING) return
        logEvent(EventType.PAUSE)
        active = r.copy(status = RunStatus.PAUSED).also { repo.update(it) }
        publish()
    }

    private suspend fun resumeInternal() {
        val r = active ?: return
        if (r.status != RunStatus.PAUSED) return
        logEvent(EventType.RESUME)
        active = r.copy(status = RunStatus.RECORDING, currentSegment = r.currentSegment + 1).also { repo.update(it) }
        signalLostFlag = false
        gapRefMono = repo.clock.mono()
        startLocation()
        publish()
    }

    private suspend fun stopInternal() {
        val r = active ?: run { stopSelf(); return }
        stopLocation(); ticker?.cancel()
        repo.endRecording(r.id)
        active = null
        Tracking._live.value = null
        Tracking._ended.value = r.id
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = lifecycleScope.launch {
            var n = 0
            while (isActive) {
                delay(1000)
                mutex.withLock {
                    val r = active
                    if (r != null && r.status == RunStatus.RECORDING && !signalLostFlag &&
                        repo.clock.mono() - gapRefMono > RunMetrics.SIGNAL_GAP_MS) {
                        signalLostFlag = true; warnings += Warning.SIGNAL_LOST
                        logEvent(EventType.SIGNAL_LOST); alert(Warning.SIGNAL_LOST)
                    }
                }
                publish()
                if (++n % 5 == 0) updateNotification()
            }
        }
    }

    private fun currentSignal(): SignalQuality {
        val f = lastFix ?: return SignalQuality.NONE
        if (repo.clock.mono() - lastFixMono > RunMetrics.STALE_FIX_MS) return SignalQuality.NONE
        return signalFor(if (f.hasAccuracy()) f.accuracy else null)
    }

    private fun publish() {
        val r = active ?: return
        val stats = runCatching { repo.stats(r, events, samples.toList(), live = true) }.getOrNull()
        Tracking._live.value = LiveRun(r.id, r.status, currentSignal(), stats, warnings.toSet(),
            when (r.kind) { RunKind.ROUTINE -> "Sesión de rutina"; RunKind.ROUTE -> "Ruta guardada"; RunKind.SHARED -> r.sharedSessionName ?: "Sesión conjunta"; else -> "Carrera libre" })
    }

    private fun updateNotification() {
        val l = Tracking.live.value ?: return
        val s = l.stats
        val text = (if (l.status == RunStatus.PAUSED) "En pausa" else "Grabando") +
            " · ${Fmt.km(s?.distanceM)} km · ${Fmt.duration(s?.activeMs)}"
        if (NotificationManagerCompat.from(this).areNotificationsEnabled())
            runCatching { NotificationManagerCompat.from(this).notify(NOTIF_ID, notification(text)) }
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).putExtra("openActiveRun", true)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val paused = active?.status == RunStatus.PAUSED
        val action = Intent(this, TrackingService::class.java).setAction(if (paused) Tracking.ACTION_RESUME else Tracking.ACTION_PAUSE)
        val pi = PendingIntent.getService(this, 1, action, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, FuckrunApp.CH_SESSION)
            .setSmallIcon(R.drawable.ic_stat_run)
            .setContentTitle("fuckrun · sesión activa")
            .setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true).setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_WORKOUT)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(open)
            .addAction(0, if (paused) "Reanudar" else "Pausar", pi)
            .build()
    }

    private fun alert(w: Warning) {
        val nm = NotificationManagerCompat.from(this)
        if (!nm.areNotificationsEnabled()) return
        runCatching {
            nm.notify(ALERT_ID + w.ordinal, NotificationCompat.Builder(this, FuckrunApp.CH_ALERTS)
                .setSmallIcon(R.drawable.ic_stat_run).setContentTitle("fuckrun").setContentText(w.text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(w.text)).setAutoCancel(true).build())
        }
    }

    override fun onDestroy() {
        stopLocation()
        runCatching { unregisterReceiver(systemReceiver) }
        super.onDestroy()
    }

    companion object { const val NOTIF_ID = 42; const val ALERT_ID = 100 }
}
