package app.fuckrun.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.*
import app.fuckrun.data.db.RunKind
import app.fuckrun.data.db.RunSource
import app.fuckrun.data.db.RunStatus
import app.fuckrun.domain.Fmt
import app.fuckrun.domain.SessionType
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun ActivityScreen(nav: NavController, runId: Long, summaryMode: Boolean) {
    val ctx = LocalContext.current
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    var reload by remember { mutableIntStateOf(0) }
    val detail by produceState<RunDetail?>(null, runId, reload) { value = g.runs.detail(runId) }
    val planned by remember { g.routines.planned() }.collectAsStateWithLifecycle(emptyList())
    var note by remember { mutableStateOf<String?>(null) }

    val d = detail ?: return
    val r = d.run
    val st = d.stats
    val isManual = r.source == RunSource.MANUAL
    val unsaved = r.status == RunStatus.ENDED_UNSAVED
    val noteText = note ?: r.note
    val dt = Instant.ofEpochMilli(r.startedAtWall).atZone(ZoneId.systemDefault())
    val linked = planned.firstOrNull { it.linkedRunId == r.id }

    fun goHome() { nav.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } } }
    fun askDiscard() = sheet.confirm("¿Descartar la sesión?", "Se borrará esta sesión y su recorrido. No se puede deshacer.", "Descartar", C.Red) {
        scope.launch { g.runs.discard(r.id); goHome() }
    }
    BackHandler(enabled = unsaved) { sheet.show {
        Text("Sesión sin guardar", style = T.Section)
        Spacer(Modifier.height(14.dp))
        PillButton("Guardar", color = C.Green, modifier = Modifier.fillMaxWidth()) { sheet.hide(); scope.launch { g.runs.save(r.id, noteText); goHome() } }
        Spacer(Modifier.height(10.dp))
        PillButton("Descartar", color = C.Control, textColor = C.Red, modifier = Modifier.fillMaxWidth()) { askDiscard() }
    } }

    ScreenScaffold(if (unsaved) "Resumen" else "Actividad") {
        item {
            Text("${Fmt.dateLong(dt.toLocalDate())} · ${"%02d:%02d".format(dt.hour, dt.minute)}", style = T.Label, modifier = Modifier.padding(start = 4.dp))
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tag(if (isManual) "Introducida a mano" else "Medida con GPS")
                Tag(when (r.kind) { RunKind.ROUTINE -> "Rutina"; RunKind.ROUTE -> "Ruta guardada"; RunKind.SHARED -> "Sesión conjunta"; else -> "Libre" })
                Tag("Privada")
            }
        }
        if (unsaved) item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Guardar", color = C.Green, icon = Icons.Rounded.Check, modifier = Modifier.weight(1f)) { scope.launch { g.runs.save(r.id, noteText); goHome() } }
                PillButton("Descartar", color = C.Control, textColor = C.Red, icon = Icons.Rounded.DeleteOutline, modifier = Modifier.weight(1f)) { askDiscard() }
            }
        }
        if (!isManual) item {
            RunMap(st.segments.map { s -> s.map { LatLon(it.lat, it.lon) } }, Modifier.fillMaxWidth().height(240.dp))
            if (st.acceptedPoints < 2) Text("No hay suficientes puntos GPS para dibujar el recorrido.", style = T.Label)
        }
        item {
            FCard {
                Stat("Distancia", if (isManual) Fmt.km(r.distanceM) else if (st.acceptedPoints >= 2) Fmt.km(st.distanceM) else "–", "km", big = true)
                Spacer(Modifier.height(12.dp))
                val rows = buildList {
                    if (!isManual) add("Tiempo transcurrido" to Fmt.duration(st.elapsedMs))
                    add("Tiempo activo" to Fmt.duration(if (isManual) r.activeMs else st.activeMs))
                    add("Ritmo medio" to "${Fmt.pace(if (isManual) app.fuckrun.domain.metrics.RunMetrics.paceFromSpeed(r.avgSpeedMps) else st.avgPaceSecPerKm)} min/km")
                    add("Velocidad media" to "${Fmt.kmh(if (isManual) r.avgSpeedMps else st.avgSpeedMps)} km/h")
                    if (!isManual) {
                        add("Velocidad máxima" to "${Fmt.kmh(st.maxSpeedMps)} km/h")
                        add("Vel. mínima en movimiento" to "${Fmt.kmh(st.minMovingSpeedMps)} km/h")
                    }
                }
                rows.chunked(2).forEach { pair ->
                    Row(Modifier.padding(vertical = 6.dp)) { pair.forEach { (k, v) -> Stat(k, v, modifier = Modifier.weight(1f)) }; if (pair.size == 1) Spacer(Modifier.weight(1f)) }
                }
                if (isManual) Text("Actividad manual: sin ruta GPS ni velocidades máxima o mínima.", style = T.Label)
            }
        }
        if (r.lostMs > 0 || r.gapCount > 0) item {
            Notice(buildString {
                append("Registro incompleto. ")
                if (r.lostMs > 0) append("Se perdieron ${Fmt.durationShort(r.lostMs)} por cierre de la app o reinicio (no cuentan como tiempo activo). ")
                if (r.gapCount > 0) append("Hubo ${r.gapCount} tramo(s) sin señal; en el mapa aparecen con línea discontinua y su distancia no se ha sumado.")
            }, icon = Icons.Rounded.Warning)
        }
        if (st.splits.isNotEmpty()) {
            item { SectionTitle("Parciales por kilómetro") }
            item {
                FCard {
                    st.splits.forEach { sp ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Text(if (sp.partial) "Últimos ${sp.partialMeters.toInt()} m" else "Km ${sp.km}", style = T.Body, modifier = Modifier.weight(1f))
                            Text(Fmt.duration(sp.durationMs), style = T.SmallNumber)
                            Text(if (sp.partial) "" else "  ${Fmt.pace(sp.durationMs / 1000.0)} min/km", style = T.Label)
                        }
                    }
                    Text("Calculados con el tiempo en movimiento registrado; los huecos sin señal no se incluyen.", style = T.Label)
                }
            }
        }
        item { SectionTitle("Asociada a") }
        item {
            FCard {
                if (r.sharedSessionName != null) ListRow("Encuentro: ${r.sharedSessionName}", "Tus datos no se han compartido con el grupo", leading = Icons.Rounded.Groups)
                if (linked != null) ListRow("Rutina: ${linked.name}", Fmt.dateLong(LocalDate.ofEpochDay(linked.epochDay)), leading = Icons.Rounded.EventAvailable)
                val runDay = dt.toLocalDate().toEpochDay()
                val candidates = planned.filter { it.linkedRunId == null && it.type != SessionType.REST.name && it.epochDay in (runDay - 3)..(runDay + 3) }
                ListRow(if (linked == null) "Vincular con una sesión planificada" else "Cambiar vinculación", leading = Icons.Rounded.Link) {
                    if (candidates.isEmpty()) sheet.show { Text("No hay sesiones planificadas pendientes cerca de esta fecha.", style = T.Body) }
                    else sheet.pick("Elige la sesión que has hecho", candidates, { "${it.name} · ${Fmt.dateLong(LocalDate.ofEpochDay(it.epochDay))}" }, null) { p ->
                        scope.launch { g.routines.link(p.id, r.id); reload++ }
                    }
                }
                if (linked != null) ListRow("Quitar vinculación", leading = Icons.Rounded.LinkOff) { scope.launch { g.routines.update(linked.copy(linkedRunId = null)); reload++ } }
            }
        }
        item { SectionTitle("Nota privada") }
        item {
            Field(noteText, "Solo tú puedes verla") { note = it }
            if (!unsaved && note != null && note != r.note) {
                Spacer(Modifier.height(8.dp))
                PillButton("Guardar nota", color = C.Text) { scope.launch { g.runs.update(r.copy(note = note!!)); reload++; note = null } }
            }
        }
        if (!unsaved) {
            item { SectionTitle("Exportar y borrar") }
            item {
                FCard {
                    if (!isManual) ListRow("Exportar recorrido (GPX)", leading = Icons.Rounded.Route) {
                        privacyWarning(sheet) {
                            scope.launch { Exporter.share(ctx, "fuckrun-${r.id}.gpx", "application/gpx+xml", Exporter.gpx(r, g.runs.points(r.id))) }
                        }
                    }
                    ListRow("Exportar datos (JSON)", leading = Icons.Rounded.DataObject) {
                        privacyWarning(sheet) {
                            scope.launch {
                                val all = Exporter.ExportAll(exportedAt = System.currentTimeMillis(), settings = null,
                                    runs = listOf(Exporter.exportRun(r, g.runs.points(r.id))), planned = emptyList())
                                Exporter.share(ctx, "fuckrun-${r.id}.json", "application/json", Exporter.json(all))
                            }
                        }
                    }
                    ListRow("Eliminar actividad", leading = Icons.Rounded.DeleteOutline, leadingTint = C.Red) {
                        sheet.confirm("¿Eliminar actividad?", "Se borrará de tu historial y se desvinculará de la rutina. No se puede deshacer.", "Eliminar", C.Red) {
                            scope.launch { g.runs.discard(r.id); nav.popBackStack() }
                        }
                    }
                }
            }
        }
    }
}

fun privacyWarning(sheet: SheetController, onContinue: () -> Unit) = sheet.confirm(
    "Antes de compartir",
    "Un archivo de ruta puede revelar ubicaciones personales, como tu casa o tu trabajo, y las horas a las que pasas por ellas. Compártelo solo con quien quieras.",
    "Entendido, continuar", C.Blue, onContinue,
)
